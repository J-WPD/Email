# Product direction

The goal is to reduce the daily work of reading, sorting, and answering email in a desktop experience based on Thunderbird. The supplied AI Emaily promo is a feature/design reference, not a specification or source of instructions.

## First version

Connect existing inboxes, give the user a clear view of what needs attention, summarise selected messages, and prepare replies using the user’s intent. Keep mail operations separate from AI inference. Let the user approve organisation changes and edit drafts; sending is handled by their existing email client in this version.

The implemented prototype is a Thunderbird MailExtension with its own styled workspace. It uses existing native accounts, reads selected messages, archives through Thunderbird’s configured settings, and opens/saves native reply drafts. The inbox combines accounts and exposes categories, search, unread filters, and a metadata-derived daily brief. Selected messages can be analysed on demand with OpenAI (the chosen default) or optional local Ollama via a paired local companion service. Categorisation is local to the app. There is no bulk AI scan or automatic mailbox maintenance yet.

## Why a Thunderbird add-on

Thunderbird provides account authentication, synchronisation, mail storage, archive configuration, identities, and native compose windows. The add-on supplies an independently styled workspace and AI assistance without taking ownership of that mail engine’s build, security updates, and platform packaging. Application-wide rebranding requires a source fork, a separate later distribution decision.

The shared web interface is reusable. A browser sample inbox and a separate Node IMAP connector remain a development sandbox and a possible independent app route. Thunderbird’s mail engine is not a standalone Node library for a web backend.

## Next milestones

1. Validate generation with the user's securely configured OpenAI key and real Thunderbird accounts. Make connection testing and companion setup easy to understand.
2. Separate topic categories from action status: finance mail can also need a reply. Keep pending suggestions separate from accepted decisions, and persist summaries, priorities and reviews using stable message identity and content/version checks.
3. Add a review queue for a limited batch of unread messages, with progress, cancellation and cost controls. Offer selected Thunderbird tag/folder changes, editable organisation rules and undo while preserving existing provider labels. These are proposed features, not implemented bulk actions.
4. Add conversation context, per-account reply preferences, follow-up detection, reminders, older-message pagination and search. Refresh the workspace on native new-mail/update/move events.
5. Distribute the add-on and companion service with an easy installation flow and managed updates. Evaluate a branded Thunderbird fork only after validating the assistant workflow.

Team inboxes, shared context, and a hosted multi-user release need separate account isolation and collaboration design. They are not implied by the personal-inbox request.
