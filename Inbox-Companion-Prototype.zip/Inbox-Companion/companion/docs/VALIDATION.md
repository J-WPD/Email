# Validation

Initial setup and native checks were run in the current cloud instance on 11 October 2026. OpenAI configuration, all 36 automated tests, syntax checks, packaging, and the simulated browser workflow were verified again on 12 October 2026. No personal mailbox credentials or model-provider keys were configured.

## Passed

- `npm ci --cache .local/npm-cache --no-audit --no-fund` installs the exact lockfile dependencies and is repeatable.
- `npm test`: 36 tests passed, zero failed or skipped. Covers the local API, session/origin protection, model output validation, simulated AI requests, native Thunderbird API contracts, and the optional IMAP connector.
- `npm run check`: JavaScript syntax checks passed.
- `npm run package:addon`: builds the verified `.local/inbox-companion.xpi` archive with the native adapter and manifest. Sending permission is absent.
- `npm audit --omit=dev --audit-level=high`: zero reported vulnerabilities.
- `python scripts/browser-smoke.py`: sample search, unread filters, category changes, simulated-model summaries and editable drafts, copying, archiving, settings, and mobile layout passed. There were no JavaScript errors or external browser resource requests. This test deliberately uses a simulated model.
- The loopback companion authenticated paired Thunderbird-origin requests in the native check. Browser sample mode shows seven messages; requesting a reply without AI opens setup guidance and produces no fabricated draft.
- OpenAI is now the default provider (`gpt-4.1-mini`). With no key, readiness reports `aiReady: false`, analysis returns labelled rule suggestions, and reply generation asks for `APP_AI_KEY`. This missing-key check made zero external requests. OpenAI request/authorization/output handling passed with a simulated provider; actual generation remains unverified.
- The add-on installs through Thunderbird 140.17 ESR’s supported temporary add-on loader in a task-owned test profile. Runtime packages were downloaded using authenticated Debian repositories with checksum/signature verification and extracted locally, without a system package installation.

## Native runtime validation

The packaged add-on passed an actual Thunderbird 140.17 ESR smoke check using reserved-address synthetic Local Folders mail:

- The toolbar action opened the styled workspace and displayed a selected native message body.
- Rule review and category application persisted in add-on storage, preserving the native message tag.
- A prepared reply opened in Thunderbird and saved to native Drafts with the matching account identity and recipient.
- Archive moved the selected fixture to Thunderbird's configured Archives folder.
- Native connection options accepted the local companion token, and authenticated health reached the running service. It correctly reported `aiReady: false`; this check did not generate an AI reply.

The full check also passed from a newly created marked profile, including initialisation of the synthetic account and folders. The reproducible driver is `scripts/thunderbird-smoke.py`. Its account and profile guards limit mutation to synthetic local fixtures; Sent and Outbox counts remain unchanged. The screenshot at `/workspace/scratch/inbox-companion-thunderbird-fresh.png` shows the actual native workspace.

Startup guards also rejected EWS, RSS, custom, and escaped-key IMAP protocol fixtures without changing their preference files. Only local-folder servers are allowed in the native test profiles.

The container exposes a read-only user-namespace mapping file, which initially crashed Thunderbird content processes. The dedicated native helper provides an explicit `--synthetic-ci` workaround that disables the nested content sandbox only for that isolated fixture process. The managed cloud sandbox remains in force. Default desktop startup keeps Thunderbird's standard sandboxing; this option must never be used with real mail. Package signatures, TLS verification, and artifact checks remain enabled.

For this Debian 13 amd64 cloud runtime, after the saved installation script has prepared the dependencies, start the companion with `npm start`. In another terminal, start the isolated native process:

```sh
cd /workspace/Email
npm run package:addon
bash scripts/start-thunderbird-runtime.sh --profile-name native-smoke --marionette-port 2828 --synthetic-ci
```

While that process remains running, use a separate terminal for the smoke check:

```sh
cd /workspace/Email
.local/native-validation-venv/bin/python scripts/thunderbird-smoke.py --port 2828 --screenshot /workspace/scratch/inbox-companion-thunderbird-fresh.png
```

Choose another port if 2828 is occupied, using the same number for both commands. The driver can initialise a marked empty test profile with a reserved-address Local Folders fixture. It refuses profiles containing network accounts or non-fixture mail. Stop the native helper with Ctrl+C when finished; it cleans up its own Thunderbird and Xvfb processes. These commands are development checks, not the normal user installation procedure.

## Not yet verified

- Synchronisation with a real provider through a user’s Thunderbird account.
- Actual Ollama inference or paid-provider requests and their output quality.
- Thunderbird 128 runtime compatibility (declared using its documented APIs; native cloud validation uses 140 ESR).
- Installation on Windows or macOS, public add-on distribution, or a fully branded Thunderbird build.
- Publication of a new environment version and restoration in a fresh task. Saved configuration is a draft until the user reviews, saves, and publishes it in environment settings.
