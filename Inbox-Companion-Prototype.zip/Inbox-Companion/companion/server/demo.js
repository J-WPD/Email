export const CATEGORIES = ['needs_reply', 'updates', 'finance', 'newsletters', 'personal'];

export function createDemoService() {
  const now = Date.now();
  const rows = [
    ['sarah', 'Sarah Chen', 'sarah@studio.example', 'Personal', 'A quick review before Thursday?', 'Hi Alex,\n\nI’ve attached the revised project outline. Could you review the scope before our meeting on Thursday? In particular, I’d like your thoughts on the launch timeline.\n\nThanks,\nSarah', 'needs_reply', 'high', 'Sarah is asking you to review the project scope and launch timeline before the meeting.'],
    ['marcus', 'Marcus Webb', 'marcus@client.example', 'Work', 'Proposal: a few questions on the scope', 'Hi Alex,\n\nThanks for sharing the proposal. Could you clarify whether the monthly fee includes ongoing maintenance? We would also like to understand how you handle change requests.\n\nBest,\nMarcus', 'needs_reply', 'high', 'Marcus needs clarification on maintenance and change requests in your proposal.'],
    ['invoice', 'Brightspace Billing', 'billing@brightspace.example', 'Work', 'Your October invoice is ready', 'Hello Alex,\n\nYour October invoice for £49 is ready in your account. Payment is scheduled for the 28th. No action is required if your card details are up to date.\n\nThe Brightspace team', 'finance', 'normal', 'Your monthly invoice is available. Check your account if your payment details changed.'],
    ['delivery', 'Parcel Post', 'updates@parcel.example', 'Personal', 'Your parcel is arriving tomorrow', 'Hi Alex,\n\nYour delivery is scheduled for tomorrow between 10 am and 2 pm. You can change your delivery preferences in your account.\n\nParcel Post', 'updates', 'normal', 'A delivery is scheduled for tomorrow between 10 am and 2 pm.'],
    ['weekend', 'Jamie', 'jamie@friends.example', 'Personal', 'Coffee this weekend?', 'Hey Alex,\n\nIt’s been too long! Are you free for coffee this weekend? Saturday morning works for me, but happy to find another time.\n\nJamie', 'personal', 'normal', 'Jamie would like to arrange coffee this weekend.'],
    ['digest', 'Design Weekly', 'hello@designweekly.example', 'Work', 'A little inspiration for your next project', 'This week in design\n\nExplore thoughtful interfaces, new independent studios, and a roundup of accessibility tools.\n\nYou’re receiving this newsletter because you subscribed. Unsubscribe in your subscription settings.', 'newsletters', 'low', 'A weekly newsletter with design inspiration and accessibility tools.'],
    ['team', 'Product Team', 'team@studio.example', 'Work', 'Weekly project update', 'Hi everyone,\n\nThis week we completed the onboarding screens and finished the first round of research. The notes are in the shared project folder. Nothing needed from you today.\n\nProduct Team', 'updates', 'low', 'The team has completed onboarding screens and the first research round.']
  ];
  const messages = rows.map((row, index) => ({
    id: `sample-${row[0]}`, from: row[1], fromAddress: row[2], account: row[3], accountId: row[3].toLowerCase(), folderId: 'INBOX', subject: row[4], body: row[5], category: row[6], priority: row[7], summary: row[8], reason: 'Sample categorisation for the preview.', source: 'rules', to: 'Alex <alex@example.com>', date: new Date(now - (index * 52 + 15) * 60000).toISOString(), unread: index < 3, starred: index === 0
  }));
  const archived = new Set();
  function find(id) {
    const message = messages.find((item) => item.id === id && !archived.has(id));
    if (!message) throw Object.assign(new Error('This message is no longer in the inbox. Refresh the inbox.'), { status: 404 });
    return message;
  }
  return {
    configured: false,
    async status() { return { configured: false, mode: 'demo', accounts: [], detail: 'Sample inbox. Configure IMAP to connect your mail.' }; },
    async listMessages() { return structuredClone(messages.filter((message) => !archived.has(message.id))); },
    async getMessage(id) { return structuredClone(find(id)); },
    async applyCategory(id, category) { if (!CATEGORIES.includes(category)) throw Object.assign(new Error('Invalid category.'), { status: 400 }); find(id).category = category; return { saved: true }; },
    async archive(id) { find(id); archived.add(id); return { archived: true }; },
    async saveDraft() { throw Object.assign(new Error('Connect a mailbox to save drafts. You can copy a sample draft instead.'), { status: 409 }); }
  };
}
