import { randomBytes } from 'node:crypto';
import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import MailComposer from 'nodemailer/lib/mail-composer/index.js';

const CATEGORIES = new Set(['needs_reply', 'updates', 'finance', 'newsletters', 'personal']);
const MAX_MESSAGES = 50;
const MAX_BODY_BYTES = 200_000;
const MAX_BODY_CHARACTERS = 20_000;

export class MailError extends Error {
  constructor(message, code = 'MAIL_UNAVAILABLE', status = 503) {
    super(message);
    this.name = 'MailError';
    this.code = code;
    this.status = status;
  }
}

function invalidId() {
  return new MailError('This message identifier is invalid.', 'INVALID_MESSAGE_ID', 400);
}

function validity(value) {
  const string = String(value ?? '');
  if (!/^\d{1,10}$/.test(string) || BigInt(string) < 1n || BigInt(string) > 4_294_967_295n) {
    throw new MailError('The mailbox did not provide a valid UID validity.', 'MAILBOX_UNAVAILABLE');
  }
  return BigInt(string).toString();
}

export function encodeMessageId(accountId, uidValidity, uid) {
  const value = { v: 1, accountId, folder: 'INBOX', uidValidity: validity(uidValidity), uid };
  if (typeof accountId !== 'string' || !accountId || !Number.isInteger(uid) || uid < 1 || uid > 4_294_967_295) {
    throw invalidId();
  }
  return `imap:${Buffer.from(JSON.stringify(value)).toString('base64url')}`;
}

export function decodeMessageId(id) {
  if (typeof id !== 'string' || id.length > 1024 || !/^imap:[A-Za-z0-9_-]+$/.test(id)) throw invalidId();
  try {
    const value = JSON.parse(Buffer.from(id.slice(5), 'base64url').toString('utf8'));
    if (value.v !== 1 || typeof value.accountId !== 'string' || !value.accountId || value.folder !== 'INBOX'
      || !Number.isInteger(value.uid) || value.uid < 1 || value.uid > 4_294_967_295
      || typeof value.uidValidity !== 'string' || validity(value.uidValidity) !== value.uidValidity) throw invalidId();
    return value;
  } catch {
    throw invalidId();
  }
}

function cleanHeader(value, length = 998) {
  return String(value ?? '').replace(/[\r\n\x00-\x1f\x7f]+/g, ' ').trim().slice(0, length);
}

function address(value) {
  const email = String(value?.address ?? '');
  if (!/^[^\s<>\x00-\x1f\x7f@]+@[^\s<>\x00-\x1f\x7f@]+$/.test(email) || email.length > 320) return null;
  return { name: cleanHeader(value?.name, 200), address: email };
}

function displayAddress(value) {
  const item = address(value);
  if (!item) return '';
  return item.name ? `${item.name} <${item.address}>` : item.address;
}

function messageId(value) {
  return typeof value === 'string' && value.length <= 998 && /^<[^<>\s\x00-\x1f\x7f]+>$/.test(value) ? value : undefined;
}

function dateString(value) {
  const date = new Date(value ?? 0);
  return Number.isNaN(date.getTime()) ? new Date(0).toISOString() : date.toISOString();
}

function normalize(account, mailbox, message, categories, body = '', bodyTruncated = false) {
  const id = encodeMessageId(account.id, mailbox.uidValidity, message.uid);
  const envelope = message.envelope ?? {};
  const sender = address(envelope.from?.[0]);
  const flags = message.flags ?? new Set();
  return {
    id,
    account: account.name,
    accountId: account.id,
    accountName: account.name,
    folderId: 'INBOX',
    from: sender?.name || sender?.address || 'Unknown sender',
    fromAddress: sender?.address || '',
    to: (envelope.to ?? []).map(displayAddress).filter(Boolean).join(', '),
    subject: cleanHeader(envelope.subject) || '(No subject)',
    date: dateString(message.internalDate ?? envelope.date),
    unread: !flags.has('\\Seen'),
    starred: flags.has('\\Flagged'),
    body,
    bodyTruncated,
    category: categories[id] ?? 'updates',
    priority: 'normal',
    summary: '',
    reason: '',
  };
}

function textPart(structure) {
  const candidates = [];
  function visit(node, attached = false) {
    if (!node) return;
    const type = String(node.type ?? '').toLowerCase();
    const isAttached = attached || String(node.disposition ?? '').toLowerCase() === 'attachment'
      || Boolean(node.dispositionParameters?.filename || node.parameters?.name) || type === 'message/rfc822';
    if (!isAttached && (type === 'text/plain' || type === 'text/html')) candidates.push(node);
    for (const child of node.childNodes ?? []) visit(child, isAttached);
  }
  visit(structure);
  return candidates.find((part) => part.type.toLowerCase() === 'text/plain') ?? candidates[0];
}

function assertCurrentMailbox(client, identity) {
  if (validity(client.mailbox?.uidValidity) !== identity.uidValidity) {
    throw new MailError('This inbox has changed. Refresh the inbox before using this message.', 'STALE_MESSAGE', 409);
  }
}

function missingMessage() {
  return new MailError('This message is no longer in the inbox. Refresh the inbox.', 'MESSAGE_NOT_FOUND', 404);
}

async function inboxLock(client, operation, readOnly = true) {
  const lock = await client.getMailboxLock('INBOX', { readOnly });
  try {
    return await operation();
  } finally {
    lock.release();
  }
}

async function specialFolder(client, specialUse, label) {
  const folders = await client.list();
  const folder = folders.find((item) => item.specialUse === specialUse && item.path !== 'INBOX'
    && !item.flags?.has('\\Noselect'));
  if (!folder) {
    if (specialUse === '\\Archive' && folders.some((item) => item.specialUse === '\\All')) {
      throw new MailError('This provider exposes All Mail rather than a designated archive folder. Provider-specific archive support is not enabled; archive this message in your email provider.', 'FOLDER_NOT_FOUND', 409);
    }
    throw new MailError(`This account has no ${label} folder marked by the email provider. Configure that folder in your email provider and try again.`, 'FOLDER_NOT_FOUND', 409);
  }
  return folder.path;
}

function assertSafeMove(client) {
  const capabilities = client.capabilities;
  const rev2 = client.enabled?.has('IMAP4REV2')
    || (capabilities?.has('IMAP4rev2') && !capabilities?.has('IMAP4rev1'));
  if (!capabilities?.has('MOVE') && !capabilities?.has('UIDPLUS') && !rev2) {
    // ImapFlow's legacy MOVE fallback expunges all pre-existing deleted messages
    // when UIDPLUS is absent, so that fallback cannot implement a selected move.
    throw new MailError('This provider cannot safely archive only the selected message over IMAP. Archive this message in your email provider.', 'ARCHIVE_UNSUPPORTED', 409);
  }
}

/** Uses IMAP for inbox reads, explicitly selected moves, and saved drafts. It never sends mail. */
export function createMailService({ accounts = [], stateDirectory, clientFactory = (options) => new ImapFlow(options) } = {}) {
  if (!Array.isArray(accounts)) throw new MailError('Mail account configuration must be an array.', 'INVALID_CONFIG', 400);
  const accountMap = new Map();
  for (const account of accounts) {
    if (!account?.id || accountMap.has(account.id) || !account.host || (account.secure !== undefined && account.secure !== true) || !account.auth?.user
      || (!account.auth.pass && !account.auth.accessToken)) {
      throw new MailError('Each email account needs a unique ID, an IMAP host, TLS, and authentication.', 'INVALID_CONFIG', 400);
    }
    accountMap.set(account.id, account);
  }
  const states = new Map(accounts.map((account) => [account.id, { status: 'configured', detail: 'Configured. Refresh the inbox to connect.' }]));
  let categoriesPromise;
  let writeQueue = Promise.resolve();

  async function loadCategories() {
    if (!categoriesPromise) {
      categoriesPromise = (async () => {
        if (!stateDirectory) return Object.create(null);
        try {
          const stored = JSON.parse(await readFile(path.join(stateDirectory, 'mail-categories.json'), 'utf8'));
          if (stored.version !== 1 || !stored.categories || typeof stored.categories !== 'object' || Array.isArray(stored.categories)) throw new Error();
          const result = Object.create(null);
          for (const [id, category] of Object.entries(stored.categories)) {
            if (!CATEGORIES.has(category)) throw new Error();
            decodeMessageId(id);
            result[id] = category;
          }
          return result;
        } catch (error) {
          if (error.code === 'ENOENT') return Object.create(null);
          throw new MailError('Local email categories could not be read. Check the configured state directory.', 'LOCAL_STATE_ERROR', 500);
        }
      })();
    }
    return categoriesPromise;
  }

  async function persistCategory(id, category) {
    const operation = writeQueue.then(async () => {
      const categories = await loadCategories();
      const updated = { ...categories, [id]: category };
      if (stateDirectory) {
        const temporary = path.join(stateDirectory, `.mail-categories-${randomBytes(8).toString('hex')}.tmp`);
        try {
          await mkdir(stateDirectory, { recursive: true, mode: 0o700 });
          await writeFile(temporary, JSON.stringify({ version: 1, categories: updated }), { mode: 0o600, flag: 'wx' });
          await rename(temporary, path.join(stateDirectory, 'mail-categories.json'));
        } catch {
          await unlink(temporary).catch(() => {});
          throw new MailError('The email category could not be saved. Check the configured state directory.', 'LOCAL_STATE_ERROR', 500);
        }
      }
      categories[id] = category;
    });
    writeQueue = operation.catch(() => {});
    await operation;
  }

  async function withAccount(account, operation) {
    let client;
    try {
      client = clientFactory({
        host: account.host,
        port: account.port ?? 993,
        secure: true,
        auth: account.auth,
        tls: { rejectUnauthorized: true },
        logger: false,
        connectionTimeout: 15_000,
        socketTimeout: 30_000,
        disableAutoIdle: true,
      });
      // ImapFlow can emit connection errors independently of the operation promise.
      client.on?.('error', () => {});
      await client.connect();
      states.set(account.id, { status: 'connected', detail: 'IMAP account connected.' });
      return await operation(client);
    } catch (error) {
      if (error instanceof MailError) throw error;
      const failure = new MailError('Unable to access this email account. Verify the IMAP host, port, and credentials in environment settings.', 'MAIL_CONNECTION_FAILED');
      states.set(account.id, { status: 'error', detail: failure.message });
      throw failure;
    } finally {
      if (client) {
        try { await client.logout(); } catch { try { client.close?.(); } catch {} }
      }
    }
  }

  function accountForId(id) {
    const identity = decodeMessageId(id);
    const account = accountMap.get(identity.accountId);
    if (!account) throw new MailError('This email account is no longer configured.', 'ACCOUNT_NOT_FOUND', 404);
    return { identity, account };
  }

  async function selectedMessage(client, identity, query) {
    assertCurrentMailbox(client, identity);
    const message = await client.fetchOne(identity.uid, query, { uid: true });
    if (!message) throw missingMessage();
    return message;
  }

  return {
    configured: accounts.length > 0,
    async status() {
      return {
        configured: accounts.length > 0,
        mode: accounts.length ? 'live' : 'demo',
        accounts: accounts.map((account) => ({ id: account.id, name: account.name, ...states.get(account.id) })),
      };
    },
    async listMessages() {
      const categories = await loadCategories();
      const results = await Promise.allSettled(accounts.map((account) => withAccount(account, (client) => inboxLock(client, async () => {
        validity(client.mailbox?.uidValidity);
        const uids = await client.search({ all: true }, { uid: true });
        const recent = (uids || []).slice(-MAX_MESSAGES);
        if (!recent.length) return [];
        const messages = [];
        for await (const message of client.fetch(recent.join(','), { uid: true, envelope: true, flags: true, internalDate: true }, { uid: true })) {
          messages.push(normalize(account, client.mailbox, message, categories));
        }
        return messages;
      }))));
      if (results.length && results.every((result) => result.status === 'rejected')) throw results[0].reason;
      return results.flatMap((result) => result.status === 'fulfilled' ? result.value : []).sort((a, b) => b.date.localeCompare(a.date));
    },
    async getMessage(id) {
      const { identity, account } = accountForId(id);
      const categories = await loadCategories();
      return withAccount(account, (client) => inboxLock(client, async () => {
        const message = await selectedMessage(client, identity, { uid: true, envelope: true, flags: true, internalDate: true, bodyStructure: true });
        const part = textPart(message.bodyStructure);
        let body = '';
        let bodyTruncated = false;
        if (part) {
          const key = part.part || 'TEXT';
          const mimeKey = part.part ? `${part.part}.MIME` : 'HEADER';
          const content = await selectedMessage(client, identity, { bodyParts: [mimeKey, { key, start: 0, maxLength: MAX_BODY_BYTES }] });
          const charset = /^[A-Za-z0-9_.-]+$/.test(part.parameters?.charset ?? '') ? part.parameters.charset : 'utf-8';
          const encoding = ['base64', 'quoted-printable', '7bit', '8bit', 'binary'].includes(part.encoding) ? part.encoding : '8bit';
          // ImapFlow returns lower-case BODY section keys, and HEADER in its own property.
          const mime = (part.part ? content.bodyParts?.get(mimeKey.toLowerCase()) : content.headers)
            ?? Buffer.from(`Content-Type: ${part.type}; charset=${charset}\r\nContent-Transfer-Encoding: ${encoding}\r\n`);
          const bytes = content.bodyParts?.get(key.toLowerCase()) ?? Buffer.alloc(0);
          const mimeHeaders = Buffer.from(`${mime.toString('latin1').replace(/(?:\r?\n)+$/, '')}\r\n\r\n`, 'latin1');
          const parsed = await simpleParser(Buffer.concat([mimeHeaders, bytes]), { skipImageLinks: true, skipTextToHtml: true });
          const text = String(parsed.text ?? '');
          bodyTruncated = text.length > MAX_BODY_CHARACTERS || bytes.length >= MAX_BODY_BYTES;
          body = text.slice(0, MAX_BODY_CHARACTERS);
        }
        return normalize(account, client.mailbox, message, categories, body, bodyTruncated);
      }));
    },
    async applyCategory(id, category) {
      if (!CATEGORIES.has(category)) throw new MailError('Choose a supported email category.', 'INVALID_CATEGORY', 400);
      const { identity, account } = accountForId(id);
      return withAccount(account, (client) => inboxLock(client, async () => {
        await selectedMessage(client, identity, { uid: true });
        await persistCategory(id, category);
        return { saved: true, category };
      }));
    },
    async archive(id) {
      const { identity, account } = accountForId(id);
      return withAccount(account, (client) => inboxLock(client, async () => {
        await selectedMessage(client, identity, { uid: true });
        const folder = await specialFolder(client, '\\Archive', 'archive');
        assertSafeMove(client);
        assertCurrentMailbox(client, identity);
        const moved = await client.messageMove(identity.uid, folder, { uid: true });
        if (!moved) throw missingMessage();
        return { archived: true, folder };
      }, false));
    },
    async saveDraft(id, body) {
      if (typeof body !== 'string' || !body.trim() || body.length > 100_000) {
        throw new MailError('A draft must contain text and be at most 100,000 characters.', 'INVALID_DRAFT', 400);
      }
      const { identity, account } = accountForId(id);
      return withAccount(account, (client) => inboxLock(client, async () => {
        const original = await selectedMessage(client, identity, { uid: true, envelope: true, headers: true });
        const parsed = await simpleParser(original.headers ?? Buffer.alloc(0), { skipImageLinks: true, skipTextToHtml: true });
        const recipient = address(parsed.replyTo?.value?.[0]) ?? address(parsed.from?.value?.[0])
          ?? address(original.envelope?.replyTo?.[0]) ?? address(original.envelope?.from?.[0]);
        if (!recipient) throw new MailError('The original email has no valid reply address.', 'INVALID_REPLY_ADDRESS', 409);
        const sender = address({ address: account.fromAddress ?? account.identity?.address ?? account.auth.user, name: account.fromName ?? account.identity?.name ?? account.name });
        if (!sender) throw new MailError('Configure a valid From email identity for this account before saving drafts.', 'INVALID_FROM_ADDRESS', 409);
        const originalSubject = cleanHeader(parsed.subject ?? original.envelope?.subject);
        const subject = /^re\s*:/i.test(originalSubject) ? originalSubject : `Re: ${originalSubject}`;
        const inReplyTo = messageId(parsed.messageId) ?? messageId(original.envelope?.messageId);
        const originals = Array.isArray(parsed.references) ? parsed.references : typeof parsed.references === 'string' ? parsed.references.split(/\s+/) : [];
        const references = [...new Set([...originals.map(messageId).filter(Boolean), ...(inReplyTo ? [inReplyTo] : [])])].slice(-32);
        const folder = await specialFolder(client, '\\Drafts', 'drafts');
        const composer = new MailComposer({ from: sender, to: recipient, subject, text: body, inReplyTo, references });
        const compiled = composer.compile();
        const content = await new Promise((resolve, reject) => compiled.build((error, buffer) => error ? reject(error) : resolve(buffer)));
        const appended = await client.append(folder, content, ['\\Draft']);
        if (!appended) throw new MailError('The email provider did not save this draft. Try again.', 'DRAFT_SAVE_FAILED');
        return { saved: true, folder };
      }));
    },
  };
}
