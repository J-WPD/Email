import { mkdir, readFile, writeFile, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { loadConfig } from './config.js';
import { createDemoService } from './demo.js';
import { createMailService } from './mail.js';
import { createAiService } from './ai.js';
import { createApplication } from './app.js';

try {
  const config = await loadConfig();
  await mkdir(config.stateDirectory, { recursive: true, mode: 0o700 });
  const tokenPath = join(config.stateDirectory, 'session-token');
  let token;
  try {
    const info = await stat(tokenPath);
    if (!info.isFile() || (info.mode & 0o077)) throw new Error('Session token file must have private permissions (chmod 600).');
    token = (await readFile(tokenPath, 'utf8')).trim();
    if (!/^[a-f0-9]{64}$/.test(token)) throw new Error('Invalid session token file. Remove only this generated file and restart.');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    token = randomBytes(32).toString('hex');
    await writeFile(tokenPath, token, { mode: 0o600, flag: 'wx' });
  }
  const mail = config.accounts.length ? createMailService({ accounts: config.accounts, stateDirectory: config.stateDirectory }) : createDemoService();
  const app = createApplication({ mail, ai: createAiService(config.ai), token, port: config.port });
  app.on('error', (error) => { console.error(error.code === 'EADDRINUSE' ? 'The selected port is already in use. Choose another PORT.' : 'The application server could not start.'); process.exitCode = 1; });
  app.listen(config.port, '127.0.0.1', () => console.log(`Inbox Companion listening on port ${config.port}. ${config.accounts.length ? 'IMAP accounts configured.' : 'Sample inbox mode.'}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => app.close(() => process.exit(0)));
} catch (error) { console.error(error.message); process.exitCode = 1; }
