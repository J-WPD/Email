import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { timingSafeEqual } from 'node:crypto';
import { CATEGORIES } from './demo.js';

const webDirectory = resolve(dirname(fileURLToPath(import.meta.url)), '../web');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' };
function failure(message, status = 400) { return Object.assign(new Error(message), { status }); }
function equalToken(supplied, expected) {
  if (typeof supplied !== 'string') return false;
  const actualBytes = Buffer.from(supplied), expectedBytes = Buffer.from(expected);
  return actualBytes.length === expectedBytes.length && timingSafeEqual(actualBytes, expectedBytes);
}
async function readJson(request) {
  if (!request.headers['content-type']?.startsWith('application/json')) throw failure('Send JSON content.', 415);
  let size = 0; const buffers = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 65536) throw failure('Request is too large.', 413);
    buffers.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(buffers).toString('utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  }
  catch { throw failure('Invalid JSON.'); }
}

export function createApplication({ mail, ai, token, port = 8765 }) {
  const server = createServer(async (request, response) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    response.setHeader('Cache-Control', 'no-store');
    const json = (status, payload) => { response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); response.end(JSON.stringify(payload)); };
    try {
      const actualPort = port || server.address()?.port;
      const allowedHosts = [`127.0.0.1:${actualPort}`, `localhost:${actualPort}`];
      if (!allowedHosts.includes(request.headers.host)) throw failure('Use the local application address.', 403);
      const origin = request.headers.origin;
      const extensionOrigin = typeof origin === 'string' && /^moz-extension:\/\/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(origin);
      if (origin && !extensionOrigin && !allowedHosts.some((host) => origin === `http://${host}`)) throw failure('Cross-origin requests are not allowed.', 403);
      if (!extensionOrigin && ['cross-site', 'same-site'].includes(request.headers['sec-fetch-site'])) throw failure('Cross-origin requests are not allowed.', 403);
      const url = new URL(request.url, `http://127.0.0.1:${actualPort}`);
      if (extensionOrigin) {
        if (!['/api/health', '/api/analyze', '/api/draft'].includes(url.pathname)) throw failure('Thunderbird can access only the AI companion endpoints.', 403);
        response.setHeader('Access-Control-Allow-Origin', origin);
        response.setHeader('Vary', 'Origin');
        if (request.method === 'OPTIONS') {
          response.setHeader('Access-Control-Allow-Methods', 'GET, POST');
          response.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Inbox-Token');
          response.writeHead(204); response.end(); return;
        }
      }
      if (url.pathname === '/api/session' && request.method === 'GET') return json(200, { token });
      if (url.pathname.startsWith('/api/')) {
        if (!equalToken(request.headers['x-inbox-token'], token)) throw failure('Reload the application to establish a session.', 401);
        if (request.method === 'GET' && url.pathname === '/api/health') return json(200, { ...await ai.health(), mode: mail.configured ? 'live' : 'demo' });
        if (request.method === 'GET' && url.pathname === '/api/mail/status') return json(200, await mail.status());
        if (request.method === 'GET' && url.pathname === '/api/messages') return json(200, await mail.listMessages());
        const match = url.pathname.match(/^\/api\/messages\/([^/]+)(?:\/(category|archive|reply))?$/);
        if (match) {
          const id = decodeURIComponent(match[1]);
          if (request.method === 'GET' && !match[2]) return json(200, await mail.getMessage(id));
          if (request.method === 'POST' && match[2]) {
            const body = await readJson(request);
            if (match[2] === 'category') {
              if (!CATEGORIES.includes(body.category)) throw failure('Choose a supported category.');
              return json(200, await mail.applyCategory(id, body.category));
            }
            if (match[2] === 'archive') return json(200, await mail.archive(id));
            if (match[2] === 'reply') {
              if (typeof body.body !== 'string' || !body.body.trim() || body.body.length > 12000) throw failure('A draft of up to 12,000 characters is required.');
              return json(200, await mail.saveDraft(id, body.body));
            }
          }
        }
        if (request.method === 'POST' && ['/api/analyze', '/api/draft'].includes(url.pathname)) {
          const body = await readJson(request);
          return json(200, url.pathname === '/api/analyze' ? await ai.analyze(body.message) : await ai.draft(body.message, { intent: body.intent, tone: body.tone }));
        }
        throw failure('This endpoint is not available.', 404);
      }
      if (!['GET', 'HEAD'].includes(request.method)) throw failure('Method not allowed.', 405);
      let path;
      try { path = decodeURIComponent(url.pathname); } catch { throw failure('Invalid path.'); }
      const target = resolve(webDirectory, `.${path === '/' ? '/index.html' : path}`);
      if (!target.startsWith(`${webDirectory}/`) || !mime[extname(target)]) throw failure('Not found.', 404);
      let content;
      try { content = await readFile(target); } catch { throw failure('Not found.', 404); }
      response.writeHead(200, { 'Content-Type': mime[extname(target)] });
      response.end(request.method === 'HEAD' ? undefined : content);
    } catch (error) {
      if (!response.headersSent) json(error.status || 500, { error: error.status ? error.message : 'The operation could not be completed. Check your account settings and try again.' });
      else response.end();
    }
  });
  return server;
}
