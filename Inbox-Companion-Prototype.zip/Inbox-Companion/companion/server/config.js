import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';

export async function loadConfig(env = process.env) {
  const port = Number(env.PORT || 8765);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be between 1024 and 65535.');
  const provider = env.AI_PROVIDER || 'ollama';
  if (!['ollama', 'openai'].includes(provider)) throw new Error('AI_PROVIDER must be ollama or openai.');
  const ollamaUrl = new URL(env.OLLAMA_URL || 'http://127.0.0.1:11434');
  if (!['http:', 'https:'].includes(ollamaUrl.protocol) || ollamaUrl.username || ollamaUrl.password || ollamaUrl.search || ollamaUrl.hash) throw new Error('Invalid OLLAMA_URL.');
  if (ollamaUrl.protocol === 'http:' && !['127.0.0.1', 'localhost', '[::1]'].includes(ollamaUrl.hostname)) throw new Error('Remote Ollama servers must use HTTPS.');
  let accounts = [];
  if (env.MAIL_ACCOUNTS_FILE) {
    const file = resolve(env.MAIL_ACCOUNTS_FILE);
    const info = await stat(file);
    if (!info.isFile() || (info.mode & 0o077)) throw new Error('MAIL_ACCOUNTS_FILE must be a private file (chmod 600).');
    let parsed;
    try { parsed = JSON.parse(await readFile(file, 'utf8')); }
    catch { throw new Error('MAIL_ACCOUNTS_FILE must contain valid JSON.'); }
    accounts = parsed.accounts;
  } else if (env.IMAP_HOST || env.IMAP_USER || env.IMAP_PASSWORD) {
    if (!env.IMAP_HOST || !env.IMAP_USER || !env.IMAP_PASSWORD) throw new Error('Set IMAP_HOST, IMAP_USER, and IMAP_PASSWORD together.');
    accounts = [{ id: 'personal', name: env.IMAP_ACCOUNT_NAME || 'Personal', host: env.IMAP_HOST, port: Number(env.IMAP_PORT || 993), secure: true, auth: { user: env.IMAP_USER, pass: env.IMAP_PASSWORD } }];
  }
  if (!Array.isArray(accounts) || accounts.length > 10) throw new Error('Configure up to ten IMAP accounts.');
  const ids = new Set();
  accounts = accounts.map((account) => {
    if (!account || !/^[a-zA-Z0-9_-]{1,40}$/.test(account.id || '') || ids.has(account.id)) throw new Error('Each account requires a unique id using letters, digits, underscores or hyphens.');
    ids.add(account.id);
    if (typeof account.host !== 'string' || !/^[a-zA-Z0-9.-]+$/.test(account.host)) throw new Error('Each account requires a valid IMAP hostname.');
    if (account.secure === false) throw new Error('Only IMAP over verified TLS is supported.');
    const accountPort = Number(account.port || 993);
    if (!Number.isInteger(accountPort) || accountPort < 1 || accountPort > 65535) throw new Error('Invalid IMAP port.');
    if (!account.auth || typeof account.auth.user !== 'string' || !account.auth.user.includes('@') || (!account.auth.pass && !account.auth.accessToken)) throw new Error('An account requires an email address and password or OAuth access token.');
    if (typeof account.name !== 'string' || !account.name.trim() || account.name.length > 100) throw new Error('Each account requires a short display name.');
    const identity = account.identity;
    if (identity && (typeof identity !== 'object' || typeof identity.name !== 'string' || identity.name.length > 100 || /[\r\n]/.test(identity.name) || typeof identity.address !== 'string' || !/^[^\s<>@]+@[^\s<>@]+$/.test(identity.address))) throw new Error('A sender identity requires a valid email address and short name.');
    if (account.fromAddress && (typeof account.fromAddress !== 'string' || !/^[^\s<>@]+@[^\s<>@]+$/.test(account.fromAddress))) throw new Error('Invalid From address.');
    if (account.fromName && (typeof account.fromName !== 'string' || account.fromName.length > 100 || /[\r\n]/.test(account.fromName))) throw new Error('Invalid From display name.');
    return { id: account.id, name: account.name, host: account.host, port: accountPort, secure: true, auth: account.auth, ...(identity ? { identity } : {}), ...(account.fromAddress ? { fromAddress: account.fromAddress } : {}), ...(account.fromName ? { fromName: account.fromName } : {}) };
  });
  return {
    port, accounts,
    stateDirectory: resolve(env.STATE_DIRECTORY || '.local'),
    ai: { provider, model: env.AI_MODEL || (provider === 'ollama' ? 'qwen3:4b' : 'gpt-4.1-mini'), ollamaUrl: ollamaUrl.href.replace(/\/$/, ''), apiKey: env.APP_AI_KEY || '' }
  };
}
