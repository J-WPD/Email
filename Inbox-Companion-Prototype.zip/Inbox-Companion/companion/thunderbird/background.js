// Opening the workspace is explicit. Loading the add-on does not read mail.
let workspaceTabId;
browser.browserAction.onClicked.addListener(async () => {
  if (workspaceTabId) {
    try {
      await browser.tabs.update(workspaceTabId, { active: true });
      return;
    } catch { workspaceTabId = undefined; }
  }
  const tab = await browser.tabs.create({ url: browser.runtime.getURL('web/index.html') });
  workspaceTabId = tab.id;
});
