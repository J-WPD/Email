const SERVICE_URL = 'http://127.0.0.1:8765';
const SETTINGS_KEY = 'companion.settings';
const CATEGORIES = ['needs_reply', 'updates', 'finance', 'newsletters', 'personal'];
const MAX_MESSAGES = 50;
const MAX_HEADERS = 1000;
const MAX_BODY = 20_000;
const LOOKBACK_DAYS = 30;

function clean(value, maximum = 1000) { return String(value ?? '').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '').slice(0, maximum); }
function nativeId(value) {
  const id = Number(value);
  if (!Number.isInteger(id) || id < 1) throw new Error('Refresh the inbox before opening this message.');
  return id;
}
function dateOf(header) {
  const date = new Date(header.date);
  return Number.isNaN(date.getTime()) ? '' : date.toISOString();
}
function emailAddresses(value) { return String(value ?? '').toLowerCase().match(/[^\s<>,;"()]+@[^\s<>,;"()]+/g) || []; }
function senderOf(author) {
  const address = emailAddresses(author)[0] || '';
  const name = String(author ?? '').replace(/<[^>]*>/g, '').replace(/^\s*"|"\s*$/g, '').trim();
  return { from: clean(name || address || 'Unknown sender'), fromAddress: address };
}
function inboxFolders(account) {
  const found = new Map();
  function visit(folder) {
    if (!folder || folder.isUnified || folder.isVirtual) return;
    if (folder.type === 'inbox' || folder.specialUse?.includes('inbox')) found.set(folder.id || `${folder.accountId}:${folder.path}`, folder);
    for (const child of folder.subFolders || []) visit(child);
  }
  for (const folder of account.folders || []) visit(folder);
  visit(account.rootFolder);
  return [...found.values()];
}
// No HTML is inserted into a document. This TB128 fallback cannot load images,
// execute code, or navigate. TB140+ uses Thunderbird's native text conversion.
function textWithoutMarkup(html) {
  const entities = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  return String(html)
    .replace(/<!--[^]*?(?:-->|$)/g, '')
    .replace(/<(script|style|template|head)\b[^>]*>[^]*?<\/\1\s*>/gi, '')
    .replace(/<\s*(?:br\b[^>]*|\/\s*(?:p|div|li|tr|h[1-6])\s*)>/gi, '\n')
    .replace(/<[^>]*>/g, '')
    .replace(/&(#x[0-9a-f]{1,6}|#\d{1,7}|amp|lt|gt|quot|apos|nbsp);/gi, (entity, name) => {
      if (name[0] !== '#') return entities[name.toLowerCase()] || entity;
      const number = name[1].toLowerCase() === 'x' ? parseInt(name.slice(2), 16) : Number(name.slice(1));
      return number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff) ? String.fromCodePoint(number) : '';
    }).replace(/\n{3,}/g, '\n\n').trim();
}
function ruleReview(message) {
  const text = `${message.subject || ''}\n${message.body || ''}`;
  let category = 'updates';
  if (/unsubscribe|newsletter|weekly digest/i.test(text)) category = 'newsletters';
  else if (/invoice|payment|receipt|billing/i.test(text)) category = 'finance';
  else if (/could you|can you|please (review|confirm|send)|your thoughts|\?/i.test(text)) category = 'needs_reply';
  const firstLine = String(message.body || '').split('\n').map((line) => line.trim()).find((line) => line.length > 35) || message.subject || 'No readable message text.';
  return { category, priority: category === 'newsletters' ? 'low' : category === 'needs_reply' ? 'high' : 'normal', summary: firstLine.slice(0, 400), reason: 'Suggested by simple keyword rules. Review before applying.', source: 'rules' };
}

/** Thunderbird native mail operations; the companion service receives only explicit AI requests. */
export async function createAdapter({ browserApi = globalThis.browser, fetchImpl = globalThis.fetch } = {}) {
  if (!browserApi?.accounts || !browserApi?.messages) throw new Error('Open this workspace from the Inbox Companion add-on in Thunderbird 128 or later.');
  let accountMap = new Map();
  let accountStates = [];
  const transientCategories = new Map();
  const storage = browserApi.storage.local;

  async function settings() { return (await storage.get(SETTINGS_KEY))[SETTINGS_KEY] || {}; }
  async function request(endpoint, payload) {
    const { token } = await settings();
    if (!/^[a-f0-9]{64}$/.test(token || '')) throw new Error('Open the add-on’s connection settings and save the local service token.');
    let response;
    try {
      response = await fetchImpl(`${SERVICE_URL}${endpoint}`, {
        method: payload === undefined ? 'GET' : 'POST', credentials: 'omit', redirect: 'error',
        headers: { 'X-Inbox-Token': token, ...(payload === undefined ? {} : { 'Content-Type': 'application/json' }) },
        ...(payload === undefined ? {} : { body: JSON.stringify(payload) }),
        signal: AbortSignal.timeout(payload === undefined ? 5000 : 95000),
      });
    } catch { throw new Error('Start the companion service on your computer at http://127.0.0.1:8765, then check the add-on’s connection settings.'); }
    let value;
    try { value = await response.json(); } catch { throw new Error('The companion service returned an unreadable response.'); }
    if (!response.ok) throw new Error(response.status === 401 ? 'The connection token was rejected. Copy the current token into the add-on’s settings.' : clean(value.error || 'The companion service could not complete this request.'));
    return value;
  }
  async function health() {
    try { return { ...await request('/api/health'), mode: 'live' }; }
    catch (error) { return { mode: 'live', aiReady: false, provider: 'companion', detail: error.message }; }
  }
  async function refreshAccounts() {
    const accounts = await browserApi.accounts.list(true);
    accountMap = new Map(accounts.map((account) => [account.id, account]));
    return accounts;
  }
  async function stableCategoryKey(header) {
    if (!header.headerMessageId || !header.folder?.accountId || !dateOf(header) || !header.author || !header.subject) return null;
    const identity = JSON.stringify([header.folder.accountId, header.headerMessageId, header.author, dateOf(header), header.subject]);
    const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(identity));
    return `companion.category.${[...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('')}`;
  }
  async function normalize(header, account) {
    const categoryKey = await stableCategoryKey(header);
    const saved = categoryKey ? (await storage.get(categoryKey))[categoryKey] : transientCategories.get(header.id);
    return {
      id: String(header.id), ...senderOf(header.author),
      account: clean(account?.name || 'Thunderbird'), accountName: clean(account?.name || 'Thunderbird'),
      accountId: header.folder?.accountId || account?.id || '', folderId: header.folder?.id || header.folder?.path || '',
      to: clean((header.recipients || []).join(', '), 2000), subject: clean(header.subject) || '(No subject)', date: dateOf(header),
      unread: !header.read, starred: Boolean(header.flagged), body: '', bodyTruncated: false,
      category: CATEGORIES.includes(saved) ? saved : 'updates', priority: 'normal', summary: '', reason: '', source: 'rules',
    };
  }
  async function currentHeader(id) {
    let header;
    try { header = await browserApi.messages.get(nativeId(id)); }
    catch { throw new Error('This message has moved or is no longer available. Refresh the inbox.'); }
    if (!header?.folder || header.external) throw new Error('This message is not available in a Thunderbird inbox. Refresh the inbox.');
    if (!accountMap.has(header.folder.accountId)) await refreshAccounts();
    return header;
  }
  async function boundedHeaders(folders) {
    const result = [];
    let listId;
    let timer;
    const deadline = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('The inbox took too long to load. Let Thunderbird finish synchronizing, then refresh.')), 15000); });
    try {
      const queried = await Promise.race([browserApi.messages.query({
        folderId: folders.map((folder) => folder.id), includeSubFolders: false,
        fromDate: new Date(Date.now() - LOOKBACK_DAYS * 86400000),
        messagesPerPage: 100, autoPaginationTimeout: 1000, returnMessageListId: true,
      }), deadline]);
      let page;
      if (typeof queried === 'string') { listId = queried; page = await Promise.race([browserApi.messages.continueList(listId), deadline]); }
      else page = queried;
      let capped = false;
      while (page) {
        listId = page.id || undefined;
        const remaining = MAX_HEADERS - result.length;
        result.push(...(page.messages || []).slice(0, remaining));
        if (result.length >= MAX_HEADERS) { capped = Boolean(page.id) || (page.messages || []).length > remaining; break; }
        if (!page.id) break;
        page = await Promise.race([browserApi.messages.continueList(page.id), deadline]);
      }
      return { headers: result, capped };
    } finally {
      clearTimeout(timer);
      if (listId) await browserApi.messages.abortList(listId).catch(() => {});
    }
  }
  return {
    mode: 'live', platform: 'thunderbird', integration: 'thunderbird',
    async listMessages() {
      const accounts = await refreshAccounts();
      if (!accounts.length) throw new Error('Add an email account in Thunderbird, then refresh this workspace.');
      const relevant = accounts.map((account) => ({ account, folders: inboxFolders(account) })).filter((item) => item.folders.length);
      if (!relevant.length) throw new Error('No inbox is available yet. Configure an email account and let Thunderbird synchronize it, then refresh.');
      const results = await Promise.allSettled(relevant.map(async ({ account, folders }) => {
        const { headers, capped } = await boundedHeaders(folders);
        const newest = [...new Map(headers.map((header) => [header.id, header])).values()].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, MAX_MESSAGES);
        return { account, capped, messages: await Promise.all(newest.map((header) => normalize(header, account))) };
      }));
      accountStates = results.map((result, index) => ({
        id: relevant[index].account.id, name: clean(relevant[index].account.name),
        status: result.status === 'fulfilled' ? 'connected' : 'error',
        detail: result.status === 'fulfilled'
          ? `Thunderbird inbox available. Showing up to 50 messages from the last ${LOOKBACK_DAYS} days.${result.value.capped ? ' A large inbox was limited to 1,000 matching headers; open Thunderbird for the complete inbox.' : ''}`
          : clean(result.reason?.message || 'This Thunderbird inbox could not be loaded.'),
      }));
      if (results.every((result) => result.status === 'rejected')) throw new Error(accountStates[0].detail);
      return results.flatMap((result) => result.status === 'fulfilled' ? result.value.messages : []).sort((a, b) => new Date(b.date) - new Date(a.date));
    },
    async getMessage(id) {
      const header = await currentHeader(id);
      if (header.headersOnly) throw new Error('Thunderbird has only downloaded the headers of this email. Download the full message in Thunderbird first.');
      let parts;
      try { parts = await browserApi.messages.listInlineTextParts(header.id); }
      catch { throw new Error('Thunderbird could not read this email. Open it in Thunderbird to download or decrypt it, then retry.'); }
      const plain = parts.filter((part) => part.contentType?.toLowerCase() === 'text/plain');
      const html = parts.filter((part) => part.contentType?.toLowerCase() === 'text/html');
      let body;
      if (plain.length) body = plain.map((part) => part.content || '').join('\n\n');
      else if (html.length) body = (await Promise.all(html.map((part) => browserApi.messengerUtilities?.convertToPlainText
        ? browserApi.messengerUtilities.convertToPlainText(part.content || '') : textWithoutMarkup(part.content || '')))).join('\n\n');
      else throw new Error('This email has no readable text body. Review it in Thunderbird before preparing a reply.');
      return { ...await normalize(header, accountMap.get(header.folder.accountId)), body: clean(body, MAX_BODY), bodyTruncated: body.length > MAX_BODY };
    },
    async applyCategory(id, category) {
      if (!CATEGORIES.includes(category)) throw new Error('Choose a supported email category.');
      const header = await currentHeader(id);
      const key = await stableCategoryKey(header);
      if (key) await storage.set({ [key]: category });
      else transientCategories.set(header.id, category);
      return { saved: true, category, persistent: Boolean(key) };
    },
    async archive(id) {
      const header = await currentHeader(id);
      await browserApi.messages.archive([header.id]);
      return { archived: true };
    },
    async openReply(id, body) {
      if (typeof body !== 'string' || !body.trim() || body.length > 12000) throw new Error('Write a reply of up to 12,000 characters before saving the draft.');
      const header = await currentHeader(id);
      const account = accountMap.get(header.folder.accountId);
      const recipients = emailAddresses([...(header.recipients || []), ...(header.ccList || []), ...(header.bccList || [])].join(', '));
      const identities = account?.identities || [];
      const identity = identities.find((item) => recipients.includes(String(item.email || '').toLowerCase())) || identities[0];
      if (!identity?.id) throw new Error('Configure a sending identity for this inbox’s account in Thunderbird before creating a reply.');
      const tab = await browserApi.compose.beginReply(header.id, 'replyToSender', { identityId: identity.id, isPlainText: true, plainTextBody: body });
      try { await browserApi.compose.saveMessage(tab.id, { mode: 'draft' }); }
      catch { throw new Error('Thunderbird opened the reply but could not save it. Review the compose window and save the draft there.'); }
      return { saved: true, tabId: tab.id };
    },
    health,
    async analyze(message) {
      if (!(await health()).aiReady) return ruleReview(message);
      return request('/api/analyze', { message });
    },
    draft: (message, { intent, tone } = {}) => request('/api/draft', { message, intent, tone }),
    async mailStatus() {
      if (!accountStates.length) {
        const accounts = await refreshAccounts();
        accountStates = accounts.map((account) => ({ id: account.id, name: clean(account.name), status: 'configured', detail: 'Configured in Thunderbird. Refresh the workspace to load the inbox.' }));
      }
      return { configured: accountMap.size > 0, mode: 'live', accounts: accountStates.map((account) => ({ ...account })) };
    },
    async getSettings() { const paired = Boolean((await settings()).token); return { serviceUrl: SERVICE_URL, paired, tokenConfigured: paired, mode: 'live', platform: 'thunderbird', integration: 'thunderbird', inboxScope: `Last ${LOOKBACK_DAYS} days; up to ${MAX_MESSAGES} messages per account.` }; },
    async saveSettings(value = {}) {
      if (value.serviceUrl && value.serviceUrl !== SERVICE_URL) throw new Error('This add-on connects only to http://127.0.0.1:8765.');
      if (value.clearToken) await storage.remove(SETTINGS_KEY);
      else if (value.token?.trim()) {
        const token = value.token.trim().toLowerCase();
        if (!/^[a-f0-9]{64}$/.test(token)) throw new Error('Paste the 64-character token from the local service’s session-token file.');
        await storage.set({ [SETTINGS_KEY]: { token } });
      }
      const paired = Boolean((await settings()).token);
      return { serviceUrl: SERVICE_URL, paired, tokenConfigured: paired, mode: 'live', platform: 'thunderbird', integration: 'thunderbird' };
    },
    openSettings: () => browserApi.runtime.openOptionsPage(),
  };
}
