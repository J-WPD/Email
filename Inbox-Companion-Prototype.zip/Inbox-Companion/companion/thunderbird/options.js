import { createAdapter } from './web/adapter.js';

const adapter = await createAdapter();
const tokenField = document.getElementById('connection-token');
const status = document.getElementById('status');
const form = document.getElementById('settings-form');
const checkButton = document.getElementById('check-connection');
const clearButton = document.getElementById('clear-token');
async function renderTokenState() {
  const settings = await adapter.getSettings();
  document.getElementById('token-state').textContent = settings.tokenConfigured
    ? 'A connection token is saved. Leave this field blank to keep it.'
    : 'No connection token is saved. Inbox browsing and rule-based review still work.';
}
function busy(value) { for (const button of form.querySelectorAll('button')) button.disabled = value; }
form.addEventListener('submit', async (event) => {
  event.preventDefault(); busy(true);
  try {
    await adapter.saveSettings({ token: tokenField.value });
    tokenField.value = '';
    await renderTokenState();
    status.textContent = 'Connection settings saved.';
  } catch (error) { status.textContent = error.message || 'Settings could not be saved.'; }
  finally { busy(false); }
});
checkButton.addEventListener('click', async () => {
  busy(true); status.textContent = 'Checking the local service…';
  try { const health = await adapter.health(); status.textContent = health.detail; }
  catch { status.textContent = 'The local service could not be reached. Start it on your computer and check the token.'; }
  finally { busy(false); }
});
clearButton.addEventListener('click', async () => {
  busy(true);
  try {
    await adapter.saveSettings({ clearToken: true }); tokenField.value = '';
    await renderTokenState(); status.textContent = 'AI disconnected. Thunderbird inbox browsing still works.';
  } catch { status.textContent = 'The saved connection could not be cleared.'; }
  finally { busy(false); }
});
await renderTokenState();
