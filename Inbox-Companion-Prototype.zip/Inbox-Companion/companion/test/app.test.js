import test from 'node:test';
import assert from 'node:assert/strict';
import { createApplication } from '../server/app.js';
import { createDemoService } from '../server/demo.js';
import { request as httpRequest } from 'node:http';

async function fixture(t) {
  const token = 'a'.repeat(64);
  const mail = createDemoService();
  const ai = { health: async () => ({ provider: 'ollama', model: 'test', aiReady: false }), analyze: async () => ({ source: 'rules' }), draft: async () => ({ source: 'ai', body: 'Test only.' }) };
  // A known Host value avoids trusting the incoming hostname for anti-rebinding checks.
  const server = createApplication({ mail, ai, token, port: 0 });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const url = `http://127.0.0.1:${server.address().port}`;
  const request = (path, options = {}) => fetch(`${url}${path}`, { ...options, headers: { 'X-Inbox-Token': token, ...options.headers } });
  const withHost = (host) => new Promise((resolve, reject) => {
    const req = httpRequest(`${url}/api/session`, { headers: { Host: host } }, (res) => { res.resume(); resolve(res.statusCode); });
    req.on('error', reject); req.end();
  });
  return { request, token, withHost };
}

test('sample inbox can be read, manually categorised, and archived', async (t) => {
  const { request } = await fixture(t);
  const messages = await (await request('/api/messages')).json();
  assert.equal(messages.length, 7);
  const id = messages[0].id;
  let response = await request(`/api/messages/${id}/category`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ category: 'personal' }) });
  assert.equal(response.status, 200);
  assert.equal((await (await request(`/api/messages/${id}`)).json()).category, 'personal');
  response = await request(`/api/messages/${id}/archive`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(response.status, 200);
  assert.equal((await (await request('/api/messages')).json()).length, 6);
  assert.equal((await request(`/api/messages/${id}`)).status, 404);
});

test('missing token, foreign origins and foreign hosts are rejected', async (t) => {
  const { request, withHost } = await fixture(t);
  assert.equal((await request('/api/messages', { headers: { 'X-Inbox-Token': '' } })).status, 401);
  assert.equal((await request('/api/session', { headers: { Origin: 'https://attacker.example' } })).status, 403);
  assert.equal(await withHost('attacker.example:8765'), 403);
  assert.equal((await request('/api/session', { headers: { 'Sec-Fetch-Site': 'same-site' } })).status, 403);
});

test('unsafe category, malformed JSON and form posts cannot modify mail', async (t) => {
  const { request } = await fixture(t);
  assert.equal((await request('/api/messages/sample-sarah/category', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"category":"delete"}' })).status, 400);
  assert.equal((await request('/api/messages/sample-sarah/archive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' })).status, 400);
  assert.equal((await request('/api/messages/sample-sarah/archive', { method: 'POST', body: '{}' })).status, 415);
  assert.equal((await (await request('/api/messages')).json()).length, 7);
});

test('private server files are unavailable over HTTP and email pages prohibit inline scripts', async (t) => {
  const { request } = await fixture(t);
  for (const path of ['/server/config.js', '/.env', '/.local/session-token']) assert.equal((await request(path)).status, 404);
  const page = await request('/');
  assert.equal(page.status, 200);
  assert.match(page.headers.get('Content-Security-Policy'), /script-src 'self'/);
  assert.match(page.headers.get('Content-Security-Policy'), /frame-ancestors 'none'/);
});

test('sample inbox cannot pretend to save a real draft', async (t) => {
  const { request } = await fixture(t);
  const response = await request('/api/messages/sample-sarah/reply', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"body":"Thanks."}' });
  assert.equal(response.status, 409);
  assert.match((await response.json()).error, /Connect a mailbox/);
});

test('Thunderbird origins can call AI only with pairing token and cannot obtain a browser session', async (t) => {
  const { request } = await fixture(t);
  const origin = 'moz-extension://12345678-abcd-4abc-abcd-123456789abc';
  let response = await request('/api/health', { headers: { Origin: origin, 'Sec-Fetch-Site': 'cross-site' } });
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('Access-Control-Allow-Origin'), origin);
  assert.equal((await request('/api/health', { headers: { Origin: origin, 'X-Inbox-Token': '' } })).status, 401);
  assert.equal((await request('/api/session', { headers: { Origin: origin } })).status, 403);
  assert.equal((await request('/api/messages', { headers: { Origin: origin } })).status, 403);
  response = await request('/api/draft', { method: 'OPTIONS', headers: { Origin: origin, 'X-Inbox-Token': '' } });
  assert.equal(response.status, 204);
  assert.equal(response.headers.get('Access-Control-Allow-Headers'), 'Content-Type, X-Inbox-Token');
});

test('non-object JSON and multibyte tokens fail safely', async (t) => {
  const { request } = await fixture(t);
  assert.equal((await request('/api/messages', { headers: { 'X-Inbox-Token': 'é'.repeat(64) } })).status, 401);
  for (const body of ['null', '[]', '1']) assert.equal((await request('/api/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })).status, 400);
});
