import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { simpleParser } from 'mailparser';
import { createMailService, decodeMessageId, encodeMessageId } from '../server/mail.js';

const account = { id: 'work', name: 'Work', host: 'imap.example.test', auth: { user: 'me@example.test', pass: 'test-password' } };
const currentId = encodeMessageId(account.id, '77', 42);

function fixture(overrides = {}) {
  const calls = [];
  const message = {
    uid: 42,
    envelope: {
      from: [{ name: 'Alice', address: 'alice@example.test' }],
      to: [{ name: 'Me', address: 'me@example.test' }],
      subject: 'A useful message',
      date: new Date('2026-10-11T10:00:00Z'),
      messageId: '<original@example.test>',
    },
    flags: new Set(),
    internalDate: new Date('2026-10-11T10:00:00Z'),
    ...overrides.message,
  };
  const client = {
    mailbox: { uidValidity: 77n },
    capabilities: new Map([['MOVE', true]]),
    enabled: new Set(),
    on() {},
    async connect() { calls.push({ operation: 'connect' }); },
    async logout() { calls.push({ operation: 'logout' }); },
    async getMailboxLock(folder, options) {
      calls.push({ operation: 'lock', folder, options });
      return { release() { calls.push({ operation: 'release' }); } };
    },
    async search(query, options) { calls.push({ operation: 'search', query, options }); return [42]; },
    async *fetch(range, query, options) {
      calls.push({ operation: 'fetch', range, query, options });
      for (const uid of String(range).split(',').map(Number)) yield { ...message, uid };
    },
    async fetchOne(uid, query, options) {
      calls.push({ operation: 'fetchOne', uid, query, options });
      if (query.bodyParts) {
        return { uid, bodyParts: new Map([
          ['3.mime', Buffer.from('Content-Type: text/plain; charset=iso-8859-1\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n')],
          ['3', Buffer.from('Caf=E9: a plain-text reply.')],
        ]) };
      }
      return { ...message, uid };
    },
    async list() {
      calls.push({ operation: 'list' });
      return [
        { path: 'Saved Messages', specialUse: '\\Archive', flags: new Set() },
        { path: 'Unsent Messages', specialUse: '\\Drafts', flags: new Set() },
      ];
    },
    async messageMove(uid, folder, options) { calls.push({ operation: 'move', uid, folder, options }); return { uidMap: new Map([[uid, 100]]) }; },
    async append(folder, content, flags) { calls.push({ operation: 'append', folder, content, flags }); return { uid: 100 }; },
    ...overrides.client,
  };
  const service = createMailService({ accounts: [account], ...overrides.service, clientFactory(options) {
    calls.push({ operation: 'clientOptions', options });
    return client;
  } });
  return { service, client, calls };
}

test('an unconfigured service reports demo mode without attempting a connection', async () => {
  const service = createMailService({ clientFactory() { assert.fail('No network connection should be attempted'); } });
  assert.equal(service.configured, false);
  assert.deepEqual(await service.status(), { configured: false, mode: 'demo', accounts: [] });
  assert.deepEqual(await service.listMessages(), []);
});

test('TLS and certificate verification are mandatory, and list fetches at most 50 metadata-only messages', async () => {
  const { service, calls } = fixture({ client: { async search(query, options) {
    calls.push({ operation: 'search', query, options });
    return Array.from({ length: 75 }, (_, index) => index + 1);
  } } });
  const messages = await service.listMessages();
  assert.equal(messages.length, 50);
  assert.equal(decodeMessageId(messages[0].id).uid, 26);
  assert.equal(messages[0].body, '');
  assert.equal(messages[0].unread, true);
  assert.equal(messages[0].fromAddress, 'alice@example.test');
  const options = calls.find((call) => call.operation === 'clientOptions').options;
  assert.equal(options.secure, true);
  assert.equal(options.tls.rejectUnauthorized, true);
  assert.equal(options.logger, false);
  assert.equal(options.connectionTimeout, 15_000);
  assert.equal(options.socketTimeout, 30_000);
  const fetching = calls.find((call) => call.operation === 'fetch');
  assert.equal(fetching.options.uid, true);
  assert.equal(fetching.query.source, undefined);
  assert.equal(fetching.query.bodyParts, undefined);
  assert.equal(calls.find((call) => call.operation === 'lock').options.readOnly, true);
  assert.equal(calls.filter((call) => call.operation === 'release').length, 1);
  assert.throws(() => createMailService({ accounts: [{ ...account, secure: false }] }), { code: 'INVALID_CONFIG' });
});

test('message reads decode only a non-attachment text part and do not mark it seen', async () => {
  const { service, calls } = fixture({ message: { bodyStructure: {
    type: 'multipart/mixed',
    childNodes: [
      { type: 'text/plain', part: '1', disposition: 'inline', dispositionParameters: { filename: 'notes.txt' } },
      { type: 'text/html', part: '2' },
      { type: 'text/plain', part: '3' },
      { type: 'application/pdf', part: '4', disposition: 'attachment' },
    ],
  } } });
  const message = await service.getMessage(currentId);
  assert.equal(message.body, 'Café: a plain-text reply.');
  assert.equal(message.bodyTruncated, false);
  assert.equal(message.unread, true);
  const reads = calls.filter((call) => call.operation === 'fetchOne');
  assert.equal(reads.length, 2);
  assert.deepEqual(reads[1].query.bodyParts, ['3.MIME', { key: '3', start: 0, maxLength: 200_000 }]);
  assert.ok(reads.every((call) => call.options.uid === true && !call.query.source));
  assert.equal(calls.find((call) => call.operation === 'lock').options.readOnly, true);
  assert.equal(calls.filter((call) => call.operation === 'release').length, 1);
});

test('single-part text uses HEADER/TEXT response fields and flags incomplete bodies', async () => {
  const { service, calls } = fixture({ message: { bodyStructure: { type: 'text/plain' } }, client: {
    async fetchOne(uid, query, options) {
      calls.push({ operation: 'fetchOne', uid, query, options });
      if (query.bodyParts) return {
        uid,
        headers: Buffer.from('Content-Type: text/plain; charset=utf-8\r\n\r\n'),
        bodyParts: new Map([['text', Buffer.from('x'.repeat(20_001))]]),
      };
      return { uid, envelope: {}, flags: new Set(), bodyStructure: { type: 'text/plain' } };
    },
  } });
  const message = await service.getMessage(currentId);
  assert.equal(message.body.length, 20_000);
  assert.equal(message.bodyTruncated, true);
  assert.deepEqual(calls.filter((call) => call.operation === 'fetchOne')[1].query.bodyParts, ['HEADER', { key: 'TEXT', start: 0, maxLength: 200_000 }]);
});

test('UIDVALIDITY prevents stale message identifiers from reading or mutating a different message', async () => {
  for (const operation of ['getMessage', 'archive', 'applyCategory', 'saveDraft']) {
    const { service, calls } = fixture({ client: { mailbox: { uidValidity: 88n } } });
    await assert.rejects(service[operation](currentId, operation === 'applyCategory' ? 'finance' : 'A reply'), { code: 'STALE_MESSAGE', status: 409 });
    assert.equal(calls.filter((call) => ['fetchOne', 'move', 'append'].includes(call.operation)).length, 0);
    assert.equal(calls.filter((call) => call.operation === 'release').length, 1);
    assert.equal(calls.filter((call) => call.operation === 'logout').length, 1);
  }
});

test('message identifiers reject non-inbox targets and invalid numeric UIDs', () => {
  for (const change of [{ folder: 'Other mailbox' }, { uid: -1 }, { uid: 4_294_967_296 }, { uidValidity: '00077' }, { v: 2 }]) {
    const id = `imap:${Buffer.from(JSON.stringify({ ...decodeMessageId(currentId), ...change })).toString('base64url')}`;
    assert.throws(() => decodeMessageId(id), { code: 'INVALID_MESSAGE_ID', status: 400 });
  }
  assert.throws(() => decodeMessageId('imap:invalid!'), { code: 'INVALID_MESSAGE_ID' });
});

test('archive moves only the chosen UID into the provider-designated archive folder', async () => {
  const { service, calls } = fixture();
  assert.deepEqual(await service.archive(currentId), { archived: true, folder: 'Saved Messages' });
  assert.equal(calls.find((call) => call.operation === 'lock').options.readOnly, false);
  assert.deepEqual(calls.find((call) => call.operation === 'move'), { operation: 'move', uid: 42, folder: 'Saved Messages', options: { uid: true } });
});

test('legacy servers cannot archive by expunging unrelated deleted messages', async () => {
  const { service, calls } = fixture({ client: { capabilities: new Map([['IMAP4rev1', true]]) } });
  await assert.rejects(service.archive(currentId), { code: 'ARCHIVE_UNSUPPORTED', status: 409 });
  assert.equal(calls.filter((call) => call.operation === 'move').length, 0);
  assert.equal(calls.filter((call) => call.operation === 'release').length, 1);
});

test('UIDPLUS and active IMAP4rev2 permit a selected archive without a MOVE extension token', async () => {
  for (const client of [
    { capabilities: new Map([['UIDPLUS', true]]) },
    { capabilities: new Map([['IMAP4rev2', true]]) },
    { capabilities: new Map([['IMAP4rev1', true], ['IMAP4rev2', true]]), enabled: new Set(['IMAP4REV2']) },
  ]) {
    const { service, calls } = fixture({ client });
    assert.equal((await service.archive(currentId)).archived, true);
    assert.equal(calls.filter((call) => call.operation === 'move').length, 1);
  }
});

test('missing archive and draft folders produce actionable errors without creating mailboxes', async () => {
  for (const operation of ['archive', 'saveDraft']) {
    const { service, calls } = fixture({ client: { async list() { return [{ path: 'INBOX', flags: new Set() }]; } } });
    await assert.rejects(service[operation](currentId, 'A reply'), (error) => error.code === 'FOLDER_NOT_FOUND' && error.message.includes('email provider'));
    assert.equal(calls.filter((call) => ['move', 'append'].includes(call.operation)).length, 0);
  }
});

test('All Mail is not treated as an archive folder without provider-specific support', async () => {
  const { service, calls } = fixture({ client: { async list() { return [{ path: '[Gmail]/All Mail', specialUse: '\\All', flags: new Set() }]; } } });
  await assert.rejects(service.archive(currentId), (error) => error.code === 'FOLDER_NOT_FOUND' && error.message.includes('Provider-specific archive support'));
  assert.equal(calls.filter((call) => call.operation === 'move').length, 0);
});

test('category changes survive service restart and concurrent writes preserve both messages', async () => {
  const stateDirectory = await mkdtemp(path.join(os.tmpdir(), 'inbox-mail-test-'));
  try {
    const { service, calls } = fixture({ service: { stateDirectory } });
    const otherId = encodeMessageId(account.id, '77', 43);
    await Promise.all([service.applyCategory(currentId, 'finance'), service.applyCategory(otherId, 'personal')]);
    const stored = JSON.parse(await readFile(path.join(stateDirectory, 'mail-categories.json'), 'utf8'));
    assert.deepEqual(stored.categories, { [currentId]: 'finance', [otherId]: 'personal' });
    const restarted = fixture({ service: { stateDirectory } }).service;
    assert.equal((await restarted.listMessages())[0].category, 'finance');
    assert.equal(calls.filter((call) => ['move', 'append'].includes(call.operation)).length, 0);
    await assert.rejects(service.applyCategory(currentId, 'not-a-category'), { code: 'INVALID_CATEGORY' });
  } finally {
    await rm(stateDirectory, { recursive: true, force: true });
  }
});

test('saved drafts preserve reply routing and threading and cannot inject extra headers', async () => {
  const { service, calls } = fixture({ message: {
    envelope: {
      from: [{ name: 'Alice', address: 'alice@example.test' }],
      subject: 'Réunion\r\nBcc: hidden@example.test',
      messageId: '<original@example.test>',
    },
    headers: Buffer.from('Reply-To: =?UTF-8?Q?Jos=C3=A9?= <reply@example.test>\r\nMessage-ID: <original@example.test>\r\nReferences: <earlier@example.test>\r\n\r\n'),
  }, service: { accounts: [{ ...account, name: 'My Inbox\r\nBcc: hidden@example.test' }] } });
  assert.deepEqual(await service.saveDraft(currentId, 'Thank you.\nI will reply tomorrow.'), { saved: true, folder: 'Unsent Messages' });
  const append = calls.find((call) => call.operation === 'append');
  assert.deepEqual(append.flags, ['\\Draft']);
  const draft = await simpleParser(append.content);
  assert.equal(draft.to.value[0].address, 'reply@example.test');
  assert.equal(draft.to.value[0].name, 'José');
  assert.equal(draft.from.value[0].address, 'me@example.test');
  assert.equal(draft.subject, 'Re: Réunion Bcc: hidden@example.test');
  assert.equal(draft.bcc, undefined);
  assert.equal(draft.inReplyTo, '<original@example.test>');
  assert.deepEqual(draft.references, ['<earlier@example.test>', '<original@example.test>']);
  assert.equal(draft.text.trim(), 'Thank you.\nI will reply tomorrow.');
  assert.equal(calls.filter((call) => call.operation === 'move').length, 0);
});

test('connection failures expose actionable status without leaking server errors or credentials', async () => {
  const { service } = fixture({ client: { async connect() { throw new Error(`AUTH failed: ${account.auth.pass} on secret-internal-host`); } } });
  await assert.rejects(service.listMessages(), (error) => error.code === 'MAIL_CONNECTION_FAILED'
    && !error.message.includes(account.auth.pass) && !error.message.includes('secret-internal-host'));
  const status = await service.status();
  assert.equal(status.accounts[0].status, 'error');
  assert.ok(!JSON.stringify(status).includes(account.auth.pass));
});
