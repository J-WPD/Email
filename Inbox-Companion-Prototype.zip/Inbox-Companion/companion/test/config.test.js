import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadConfig } from '../server/config.js';

test('default setup uses sample inbox and local AI', async () => {
  const config = await loadConfig({});
  assert.equal(config.accounts.length, 0);
  assert.equal(config.ai.provider, 'ollama');
  assert.equal(config.ai.ollamaUrl, 'http://127.0.0.1:11434');
});

test('incomplete accounts, plaintext remote AI and invalid ports are rejected', async () => {
  await assert.rejects(loadConfig({ IMAP_HOST: 'imap.example.com' }), /Set IMAP_HOST/);
  await assert.rejects(loadConfig({ OLLAMA_URL: 'http://remote.example.com' }), /HTTPS/);
  await assert.rejects(loadConfig({ PORT: '0' }), /PORT/);
});

test('private account configuration loads multiple TLS accounts without exposing credentials', async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'inbox-config-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const file = join(directory, 'accounts.json');
  const accounts = [{ id: 'work', name: 'Work', host: 'imap.example.com', auth: { user: 'alex@example.com', pass: 'fake-test-password' } }];
  await writeFile(file, JSON.stringify({ accounts }), { mode: 0o600 });
  const config = await loadConfig({ MAIL_ACCOUNTS_FILE: file });
  assert.equal(config.accounts[0].secure, true);
  assert.equal(config.accounts[0].port, 993);
  await writeFile(file, JSON.stringify({ accounts: [{ ...accounts[0], secure: false }] }));
  await assert.rejects(loadConfig({ MAIL_ACCOUNTS_FILE: file }), /verified TLS/);
});
