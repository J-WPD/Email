import test from 'node:test';
import assert from 'node:assert/strict';
import { createAdapter } from '../thunderbird/adapter.js';

function fixture() {
  const saved = {};
  const calls = { query: [], read: [], archive: [], reply: [], save: [], fetch: [] };
  const folder = { id: 'a://INBOX', accountId: 'a', path: '/INBOX', type: 'inbox' };
  const account = { id: 'a', name: 'Personal', folders: [folder], identities: [{ id: 'primary', email: 'alex@example.com' }, { id: 'alias', email: 'work@example.com' }] };
  const header = { id: 10, headerMessageId: 'stable@example.com', folder, author: 'Sam <sam@example.com>', recipients: ['Work <work@example.com>'], subject: 'Could you review the quote?', date: new Date(), read: false, flagged: true };
  const browserApi = {
    accounts: { list: async () => [account] },
    storage: { local: {
      get: async (key) => ({ [key]: saved[key] }),
      set: async (value) => Object.assign(saved, value),
      remove: async (key) => { delete saved[key]; }
    } },
    runtime: { openOptionsPage: async () => {} },
    messages: {
      query: async (info) => { calls.query.push(info); return { messages: [header], id: null }; },
      get: async (id) => { if (id !== header.id) throw new Error('not found'); return header; },
      listInlineTextParts: async (id) => { calls.read.push(id); return [{ contentType: 'text/plain', content: 'Hi Alex, could you review the revised quote? Thanks, Sam' }]; },
      archive: async (ids) => calls.archive.push(ids),
      abortList: async () => {},
    },
    compose: {
      beginReply: async (...args) => { calls.reply.push(args); return { id: 31 }; },
      saveMessage: async (...args) => calls.save.push(args),
    },
  };
  const fetchImpl = async (...args) => { calls.fetch.push(args); return Response.json({ provider: 'ollama', model: 'test-model', aiReady: true, mode: 'demo' }); };
  return { browserApi, fetchImpl, calls, header, account, saved };
}

test('native list uses configured inboxes and bounded metadata queries, without reading or sending content', async () => {
  const data = fixture(), adapter = await createAdapter(data);
  const messages = await adapter.listMessages();
  assert.equal(adapter.platform, 'thunderbird');
  assert.equal(adapter.mode, 'live');
  assert.deepEqual(data.calls.query[0].folderId, ['a://INBOX']);
  assert.equal(data.calls.query[0].includeSubFolders, false);
  assert.ok(data.calls.query[0].fromDate instanceof Date);
  assert.equal(messages[0].fromAddress, 'sam@example.com');
  assert.equal(messages[0].body, '');
  assert.equal(messages[0].unread, true);
  assert.equal(data.calls.read.length, 0);
  assert.equal(data.calls.fetch.length, 0);
});

test('message reading and native HTML fallback remain text-only and require no AI service', async () => {
  const data = fixture(), adapter = await createAdapter(data);
  await adapter.listMessages();
  let message = await adapter.getMessage('10');
  assert.match(message.body, /revised quote/);
  data.browserApi.messages.listInlineTextParts = async () => [{ contentType: 'text/html', content: '<script>steal()</script><p>Hello &amp; welcome</p><img src="https://tracker.example"><p>Reply please</p>' }];
  message = await adapter.getMessage('10');
  assert.equal(message.body, 'Hello & welcome\nReply please');
  assert.equal(data.calls.fetch.length, 0);
  assert.equal(message.body.includes('steal'), false);
});

test('categories persist by stable message identity rather than volatile Thunderbird numeric id', async () => {
  const data = fixture(), adapter = await createAdapter(data);
  await adapter.listMessages();
  await adapter.applyCategory('10', 'finance');
  data.header.id = 20;
  const restarted = await createAdapter(data);
  assert.equal((await restarted.listMessages())[0].category, 'finance');
  await assert.rejects(restarted.getMessage('10'), /no longer available/);
});

test('archive uses Thunderbird configuration and draft saving selects the correct account identity', async () => {
  const data = fixture(), adapter = await createAdapter(data);
  await adapter.listMessages();
  await adapter.archive('10');
  assert.deepEqual(data.calls.archive, [[10]]);
  assert.equal((await adapter.openReply('10', 'Thanks. Could you send the quote?')).saved, true);
  assert.deepEqual(data.calls.reply[0], [10, 'replyToSender', { identityId: 'alias', isPlainText: true, plainTextBody: 'Thanks. Could you send the quote?' }]);
  assert.deepEqual(data.calls.save[0], [31, { mode: 'draft' }]);
});

test('missing service pairing keeps native mail and labelled rules available without exposing a token', async () => {
  const data = fixture(), adapter = await createAdapter(data);
  const health = await adapter.health();
  assert.equal(health.aiReady, false);
  assert.equal(health.mode, 'live');
  assert.equal((await adapter.analyze({ subject: 'Please review', body: 'Could you review the quote?' })).source, 'rules');
  assert.equal(data.calls.fetch.length, 0);
  await adapter.saveSettings({ token: 'a'.repeat(64) });
  const settings = await adapter.getSettings();
  assert.equal(settings.paired, true);
  assert.equal(Object.hasOwn(settings, 'token'), false);
  assert.equal((await adapter.health()).mode, 'live');
  assert.equal(data.calls.fetch[0][0], 'http://127.0.0.1:8765/api/health');
  assert.equal(data.calls.fetch[0][1].headers['X-Inbox-Token'], 'a'.repeat(64));
});

test('empty Thunderbird profile produces account guidance, not an invented inbox', async () => {
  const data = fixture(); data.browserApi.accounts.list = async () => [];
  const adapter = await createAdapter(data);
  await assert.rejects(adapter.listMessages(), /Add an email account/);
});
