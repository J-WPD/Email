# Inbox Companion for Thunderbird

A desktop email assistant built as a Thunderbird add-on, inspired by the unified inbox, prioritisation, and reply preparation in the AI Emaily reference. It provides its own styled workspace and uses Thunderbird for existing accounts, message storage, archiving, and native reply drafts. A local Node companion supplies optional AI. This is an initial prototype, not a rebranded Thunderbird distribution.

## What works

- A custom Thunderbird workspace with a unified inbox, search, unread filters, categories, a daily brief, and readable messages.
- Your existing Thunderbird accounts and authentication; no separate email password is needed for the add-on.
- Native archive actions using Thunderbird’s configured archive settings and edited replies saved in Thunderbird’s compose window as drafts.
- Local category persistence using stable message identity; provider tags are preserved.
- On-demand AI summaries, category suggestions, and reply preparation through local Ollama or optional OpenAI. You supply what the reply should say, choose a tone, and edit the result before saving.
- Rule-based suggestions when an AI model is unavailable. These are labelled; the app does not fabricate AI replies.
- A separate browser sample inbox for development, plus an optional direct IMAP connector for a future independent app.

The add-on displays up to 50 messages per account from the last 30 days, processing at most 1,000 matching headers per account. It reports when a large inbox is limited. Message bodies are read only when selected; long text is shortened and flagged. Attachments and remote images are not displayed. Sending, deleting, automatic mailbox changes, full historical indexing, team sharing, and application-wide rebranding are outside this version. Categorisation stays in this app; it does not rewrite provider labels.

## Install the Thunderbird add-on

Requires Thunderbird 128 or later; 140 ESR is recommended. No Thunderbird source build is needed.

```sh
cd /workspace/Email
npm ci --cache .local/npm-cache --no-audit --no-fund
npm run package:addon
```

In Thunderbird, open **Add-ons and Themes**, choose **Install Add-on From File** from the menu, and select `.local/inbox-companion.xpi`. Click the Inbox Companion toolbar action to open its workspace. Existing email accounts must already be configured in Thunderbird. Categories, reading, and native actions work without AI. Development can also use Thunderbird’s supported temporary add-on loader.

The styling applies to the add-on workspace. A completely branded desktop application would require a maintained Thunderbird fork; that is a later distribution decision.

## Pair the AI companion

Start the Node service with `npm start` on the same computer as Thunderbird. It creates a private `.local/session-token` file. In the add-on’s connection options, paste that local service token and save. Never paste it into chat. This token authorises requests to the local AI service; it is not an email password or model-provider API key. Model-provider credentials remain on the server.

The add-on connects only to the local service on port 8765. It sends selected email text only for an explicit AI request. Thunderbird receives only access to the companion’s health, analysis, and draft endpoints; it cannot obtain the browser session token. Reading native mail does not require the companion. To revoke pairing, stop the service, remove only its generated session-token file, restart, and re-pair.

## Run the companion and optional browser demo

Use Node.js 24+ (the development environment uses 24.19.0).

```sh
cd /workspace/Email
npm ci --cache .local/npm-cache --no-audit --no-fund
npm start
```

Open the local app on port 8765 in your own browser. `npm run dev` restarts the service when backend files change. `npm test` runs the automated checks and `npm run check` checks JavaScript syntax. Sample inbox edits reset on service restart. Real-account categories persist in the ignored `.local` directory.

The server binds only to loopback. Keep it local in this version. Publication of the cloud development environment saves a development snapshot; it does not install an add-on in your personal Thunderbird or host a public app.

## Enable AI

The default is a local [Ollama](https://ollama.com/) server. Install Ollama on the same machine, start it, and download a model:

```sh
ollama serve
```

In another terminal:

```sh
ollama pull qwen3:4b
```

The 4B model needs several GB of disk/RAM; choose a smaller available model if necessary and set `AI_MODEL` to its exact installed name. Model quality varies, and generated drafts require review. Email text is sent only to the configured model when you request analysis or a reply. The morning brief is computed from inbox metadata and suggestions, not a separate model call.

For optional cloud generation, copy `.env.example` to `.env`, set `AI_PROVIDER=openai`, `AI_MODEL=gpt-4.1-mini`, and provide `APP_AI_KEY` securely on the server. `.env` is ignored; use file mode 600 if it contains credentials. Restart the service. Restricted cloud networking must allow `api.openai.com`. This option sends the selected email’s sender, subject, date, and text plus your reply instructions to OpenAI when you click an AI action. API charges and provider data policies apply. Do not paste a key into chat or the browser.

## Optional direct IMAP browser mode

This section applies only to the separate browser app. The Thunderbird add-on uses your existing Thunderbird accounts and does not need IMAP environment variables or a credentials file.

Start with an account that supports authenticated IMAP over TLS. Basic password authentication is disabled by many providers; use an app password where the provider supports one, or a valid OAuth access token obtained separately. Gmail and Microsoft OAuth sign-in and token renewal are not implemented yet.

For one account, set `IMAP_HOST`, `IMAP_USER`, `IMAP_PASSWORD`, and optionally `IMAP_ACCOUNT_NAME` in the private server environment or ignored `.env`. The default IMAP port is 993 and certificate verification remains enabled. Restart the service. The app then switches from sample mode to live mode; account failures are errors, not replaced with sample messages.

For multiple accounts, create a private JSON file outside version control, then set `MAIL_ACCOUNTS_FILE` to its absolute path:

```json
{
  "accounts": [
    {
      "id": "personal",
      "name": "Personal",
      "host": "imap.example.com",
      "port": 993,
      "secure": true,
      "auth": {
        "user": "you@example.com",
        "pass": "ENTER_SECURELY_ON_YOUR_MACHINE"
      },
      "identity": {
        "name": "Your Name",
        "address": "you@example.com"
      }
    }
  ]
}
```

Restrict that file with `chmod 600`. Use `auth.accessToken` instead of `auth.pass` for a separately obtained OAuth token. Identity defaults to the account name and login email. Configured aliases must be permitted by your provider.

Archive and draft folders must be advertised by the provider as the IMAP special-use folders `\Archive` and `\Drafts`. The app reports a clear error instead of guessing or creating folders. Gmail’s All Mail (`\All`) archive behavior needs a provider-specific implementation; Gmail archiving is not supported in this version. Read-only IMAP metadata/text retrieval does not mark messages as read. Attachments and remote images are not retrieved or displayed. Long text is capped and flagged; read the complete original before acting on a shortened message.

IMAP connections use TCP/TLS, not the cloud HTTPS secret proxy. A hosted product needs OAuth with encrypted credential storage and the appropriate IMAP network access; do not declare an HTTPS proxy credential and assume it supplies a raw IMAP password.

## Architecture and next steps

`web/` is the shared interface. Packaging places `thunderbird/adapter.js` at the interface boundary for native account, message, archive, and compose APIs. Native numeric message IDs are used only in the current runtime; category persistence uses a hash of stable message metadata. Thunderbird 140 uses native HTML-to-text conversion; 128 has a string-only fallback with no DOM insertion or remote resource loads.

`server/ai.js` owns model calls. Email content is untrusted data, and the model has no mail-action tools. Explicit user actions execute native operations independently of model output. `web/adapter.js`, `server/mail.js`, and `server/demo.js` retain a browser development sandbox and optional independent IMAP path. Direct IMAP message identifiers include UIDVALIDITY and UID to reject stale targets.

Next steps are validation with your own Thunderbird accounts and chosen model, deeper inbox indexing, a review queue for suggested organisation, reminders/follow-ups, and distribution. A Thunderbird fork could later provide application-wide branding; an independent desktop wrapper would instead use the direct IMAP connector and need its own OAuth/keychain integration.

## Validation limits

The packaged add-on was also exercised in actual Thunderbird 140 ESR with synthetic local messages: workspace reading, categories, preserved native tags, account-matched reply drafts, archiving, and local companion pairing passed.

`npm test` covers the local API, simulated AI provider contracts, native Thunderbird API contracts, and the optional IMAP connector. Browser checks exercise the sample inbox and simulated-model reply flow. These checks do not prove live provider-account sync or actual model quality. Consult `docs/VALIDATION.md` for the native check commands and limitations. Configure your separately chosen model and real accounts before relying on AI suggestions.
