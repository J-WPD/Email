export async function createAdapter() {
  let token;
  const sessionResponse = await fetch('/api/session', { credentials: 'same-origin' });
  if (!sessionResponse.ok) throw new Error('Cannot connect to the inbox service.');
  ({ token } = await sessionResponse.json());
  async function request(path, body) {
    const response = await fetch(path, { method: body === undefined ? 'GET' : 'POST', credentials: 'same-origin', headers: { 'X-Inbox-Token': token, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const value = await response.json();
    if (!response.ok) throw new Error(value.error || 'The request could not be completed.');
    return value;
  }
  const health = await request('/api/health');
  const messagePath = (id) => `/api/messages/${encodeURIComponent(id)}`;
  return {
    mode: health.mode,
    listMessages: () => request('/api/messages'),
    getMessage: (id) => request(messagePath(id)),
    analyze: (message) => request('/api/analyze', { message }),
    draft: (message, { intent, tone }) => request('/api/draft', { message, intent, tone }),
    applyCategory: (id, category) => request(`${messagePath(id)}/category`, { category }),
    archive: (id) => request(`${messagePath(id)}/archive`, {}),
    openReply: (id, body) => request(`${messagePath(id)}/reply`, { body }),
    health: () => request('/api/health'),
    mailStatus: () => request('/api/mail/status'),
    getSettings: async () => ({ serviceUrl: location.origin, token: '', mode: health.mode }),
    saveSettings: async () => ({ serviceUrl: location.origin, mode: health.mode })
  };
}
