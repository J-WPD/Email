const icons = {
  mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
  inbox: '<path d="m5 4-3 10v5a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1v-5L19 4Z"/><path d="M2 14h6l2 3h4l2-3h6"/>',
  reply: '<path d="m9 4-6 6 6 6"/><path d="M3 10h11a7 7 0 0 1 7 7v3"/>',
  updates: '<path d="M20 7a9 9 0 0 0-15-3L2 7m0-5v5h5M4 17a9 9 0 0 0 15 3l3-3m0 5v-5h-5"/>',
  finance: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h3"/>',
  newsletters: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h3M8 18h7"/>',
  personal: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  sparkle: '<path d="m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3Z"/><path d="m20 2 .5 1.5L22 4l-1.5.5L20 6l-.5-1.5L18 4l1.5-.5Z"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  chevron: '<path d="m9 5 7 7-7 7"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  settings: '<path d="m9 3-.7 2.4-2.5 1L3.5 6 2 8.6l1.9 1.7v3.4L2 15.4 3.5 18l2.3-.4 2.5 1L9 21h6l.7-2.4 2.5-1 2.3.4 1.5-2.6-1.9-1.7v-3.4L22 8.6 20.5 6l-2.3.4-2.5-1L15 3Z"/><circle cx="12" cy="12" r="3"/>',
  archive: '<rect x="3" y="3" width="18" height="5" rx="1"/><path d="M5 8v12h14V8M10 12h4"/>',
  tag: '<path d="M3 3h8l10 10-8 8L3 11Z"/><circle cx="7.5" cy="7.5" r=".5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
  filter: '<path d="M4 6h16M7 12h10M10 18h4"/><circle cx="8" cy="6" r="1"/><circle cx="16" cy="12" r="1"/>',
  refresh: '<path d="M20 8a9 9 0 1 0 1 8M20 3v5h-5"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  warning: '<path d="m12 3 10 18H2Z"/><path d="M12 9v5m0 3v.1"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
  feather: '<path d="M20 4a6 6 0 0 0-9 0L4 14v6h6l10-7a6 6 0 0 0 0-9ZM4 20l11-11M8 14h5"/>',
  bulb: '<path d="M9 18h6m-6 3h6M8 15a7 7 0 1 1 8 0l-1 3H9Z"/>',
};
const icon = (name, extra = '') => `<svg ${extra} aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.mail}</svg>`;
const categories = {
  all: { label: 'All inbox', icon: 'inbox' },
  needs_reply: { label: 'Needs a reply', icon: 'reply' },
  updates: { label: 'Updates', icon: 'updates' },
  finance: { label: 'Finance', icon: 'finance' },
  newsletters: { label: 'Newsletters', icon: 'newsletters' },
  personal: { label: 'Personal', icon: 'personal' },
};
const state = {
  adapter: null, messages: [], selectedId: null, filter: 'all', query: '', unreadOnly: false,
  activeTab: 'overview', health: null, mailStatus: null, settings: null, analyses: new Map(), drafts: new Map(),
  busy: new Set(), error: '', settingsOpen: false, toastTimer: null, selectionRevision: 0,
};
const app = document.querySelector('#app');
const el = (tag, className = '', content) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content !== undefined) node.textContent = content;
  return node;
};
const $ = (id) => document.getElementById(id);
const svgNode = (name) => {
  const holder = el('span');
  holder.innerHTML = icon(name);
  return holder.firstElementChild;
};
const button = (text, className = '', iconName, action) => {
  const node = el('button', className);
  node.type = 'button';
  if (iconName) node.append(svgNode(iconName));
  node.append(el('span', 'label', text));
  if (action) node.addEventListener('click', action);
  return node;
};
const initials = (text = '') => text.split(/[\s@.]+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || 'EM';
const categoryLabel = (key) => categories[key]?.label || 'Uncategorized';
const isThunderbird = () => state.adapter?.platform === 'thunderbird';
const saveDraftLabel = () => state.adapter?.mode === 'demo' ? 'Copy draft' : isThunderbird() ? 'Save draft in Thunderbird' : 'Save draft to mailbox';
const selectedMessage = () => state.messages.find((m) => String(m.id) === String(state.selectedId));
const analysisFor = (m) => state.analyses.get(String(m.id)) || {
  summary: m.summary || '', category: m.category, priority: m.priority || 'normal', reason: m.reason || '', source: m.source === 'ai' ? 'ai' : 'rules',
};
const dateText = (value, detail = false) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  if (detail) return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
  const today = new Date();
  if (date.toDateString() === today.toDateString()) return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(date);
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(date);
};
function visibleMessages() {
  const query = state.query.trim().toLowerCase();
  return state.messages.filter((m) =>
    (state.filter === 'all' || analysisFor(m).category === state.filter) &&
    (!state.unreadOnly || m.unread) &&
    (!query || [m.from, m.fromAddress, m.subject, m.body].some((part) => String(part || '').toLowerCase().includes(query))),
  );
}

function shell() {
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar" id="sidebar" aria-label="Inbox navigation">
        <div class="brand"><span class="brand-mark">${icon('mail')}</span><div class="brand-name">Inbox<span>Companion<span class="visually-hidden">, your email assistant</span></span></div></div>
        <div>
          <p class="nav-label">Your workspace</p>
          <nav class="nav-list" id="main-navigation"></nav>
          <div class="sidebar-divider"></div>
        </div>
        <div>
          <p class="nav-label">Smart categories</p>
          <nav class="nav-list" id="category-navigation"></nav>
        </div>
        <div class="sidebar-bottom">
          <div class="sidebar-help"><div class="help-icon">${icon('bulb')}</div><h3>A little help. A lot of calm.</h3><p>Your assistant prepares.<br>You always have the final say.</p><button id="sidebar-setup" type="button">Meet your companion ${icon('arrow')}</button></div>
          <div class="account"><div class="avatar" id="account-avatar">IC</div><div class="account-info"><strong id="account-name">Your workspace</strong><span id="account-email">Inbox Companion</span></div>${icon('down')}</div>
        </div>
      </aside>
      <main class="main">
        <header class="topbar">
          <div class="breadcrumb"><button class="icon-button mobile-menu" id="mobile-menu" type="button" aria-label="Toggle inbox navigation" aria-expanded="false">${icon('menu')}</button>${icon('inbox')}<span>Workspace</span>${icon('chevron', 'class="breadcrumb-chevron"')}<strong>Inbox</strong></div>
          <div class="topbar-right"><button class="connection-pill" id="connection-pill" type="button" aria-label="Connection settings"><span class="connection-dot"></span><span id="connection-text">Checking connection</span></button><button class="icon-button" id="settings-button" type="button" aria-label="Open settings">${icon('settings')}</button></div>
        </header>
        <section class="page-heading" aria-labelledby="page-title"><div><p class="eyebrow">Less noise. More focus.</p><h1 id="page-title">A calmer inbox starts here.</h1><p class="heading-copy">A little clarity for your email. A little more time for you.</p></div><span class="sample-chip" id="mode-chip">${icon('mail')}<span>Connecting</span></span></section>
        <section class="brief-card" aria-labelledby="brief-title">
          <div class="brief-copy"><div class="brief-overline">${icon('sparkle')}Your inbox at a glance</div><h2 id="brief-title">Your morning brief</h2><p id="brief-description">Getting your inbox ready.</p><button id="brief-review" type="button">Review what needs a reply ${icon('arrow')}</button></div>
          <div class="brief-stats"><div class="brief-stat"><strong id="brief-needs-count">—</strong><span>need a reply</span></div><div class="brief-stat"><strong id="brief-high-count">—</strong><span>high priority</span></div></div>
          <div class="brief-art" aria-hidden="true"><svg viewBox="0 0 290 180" fill="none"><circle cx="227" cy="93" r="84" stroke="#43664b" stroke-width=".8"/><circle cx="227" cy="93" r="110" stroke="#375c43" stroke-width=".8"/><circle cx="227" cy="93" r="137" stroke="#30583e" stroke-width=".8"/><g transform="translate(154 37) rotate(14 48 60)"><rect width="98" height="124" rx="10" fill="#376548"/><rect x="13" y="16" width="38" height="5" rx="2.5" fill="#6c9366"/><rect x="13" y="32" width="72" height="3" rx="1.5" fill="#567e54"/><rect x="13" y="41" width="62" height="3" rx="1.5" fill="#567e54"/><rect x="13" y="65" width="72" height="3" rx="1.5" fill="#567e54"/></g><g transform="translate(134 43) rotate(-10 48 60)"><rect width="98" height="120" rx="10" fill="#deead2"/><rect x="13" y="16" width="23" height="18" rx="5" fill="#becfaf"/><path d="m17 22 7 5 7-5" stroke="#78966a" stroke-width="1.3"/><rect x="13" y="49" width="61" height="4" rx="2" fill="#9db58b"/><rect x="13" y="60" width="71" height="3" rx="1.5" fill="#bfd0b4"/><rect x="13" y="69" width="63" height="3" rx="1.5" fill="#bfd0b4"/><rect x="13" y="91" width="39" height="14" rx="4" fill="#acc69a"/><path d="m71 96 3 3 5-6" stroke="#6f925b" stroke-width="1.5"/></g><circle cx="239" cy="58" r="17" fill="#8fac75"/><path d="m232 58 5 5 9-10" stroke="#eff5e6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="m124 38 2-6 2 6 6 2-6 2-2 6-2-6-6-2Z" fill="#9bb985"/></svg></div>
        </section>
        <div id="error-container" aria-live="polite"></div>
        <section aria-label="Email workspace">
          <div class="workspace-heading"><h2 id="inbox-title">All inbox <span class="count" id="inbox-count"></span></h2><div class="toolbar-actions"><button id="unread-filter" class="small-button filter-toggle" type="button" aria-pressed="false">${icon('filter')}Unread only</button><button id="refresh-button" class="small-button" type="button">${icon('refresh')}Refresh</button></div></div>
          <div class="workspace">
            <div class="inbox-column"><label class="search-wrap" for="inbox-search">${icon('search')}<input id="inbox-search" type="search" placeholder="Search your inbox…" autocomplete="off" aria-label="Search messages"><kbd aria-hidden="true">/</kbd></label><div class="inbox-label"><span>Your messages</span><span id="sort-description">Newest first</span></div><div id="message-list" class="message-list" aria-label="Messages"><div class="loading-view"><span class="loading-spinner"></span>Opening your inbox</div></div></div>
            <article class="reading-column" id="reading-column" aria-label="Selected email"><div class="panel-empty">${icon('mail')}<p>Select a message to get started.</p></div></article>
            <aside class="assistant-column" aria-label="Email companion"><div class="assistant-header-wrap"><div class="assistant-heading"><span class="sparkle-icon">${icon('sparkle')}</span>Your companion<span class="beta">Preview</span></div><div class="assistant-tabs" role="tablist" aria-label="Assistant views"><button id="overview-tab" class="assistant-tab active" role="tab" aria-selected="true" aria-controls="overview-panel" type="button">Overview</button><button id="reply-tab" class="assistant-tab" role="tab" aria-selected="false" aria-controls="reply-panel" tabindex="-1" type="button">Prepare reply</button></div></div><div id="overview-panel" class="assistant-panel" role="tabpanel" aria-labelledby="overview-tab"></div><div id="reply-panel" class="assistant-panel reply-panel" role="tabpanel" aria-labelledby="reply-tab" hidden></div></aside>
          </div>
        </section>
        <footer class="bottom-note"><span>${icon('shield')}You review every reply. Your companion never sends email.</span><span id="preview-note">Sample messages · rule-based preview</span></footer>
      </main>
    </div>
    <div id="toast-container" role="status" aria-live="polite"></div>
    <div id="modal-container"></div>`;
  $('settings-button').addEventListener('click', openSettings);
  $('connection-pill').addEventListener('click', openSettings);
  $('sidebar-setup').addEventListener('click', openSettings);
  $('brief-review').addEventListener('click', () => filterBy('needs_reply'));
  $('refresh-button').addEventListener('click', () => refresh());
  $('unread-filter').addEventListener('click', () => { state.unreadOnly = !state.unreadOnly; syncSelection(); renderInbox(); renderReading(); renderAssistant(); loadSelectedBody(); });
  $('inbox-search').addEventListener('input', (event) => { state.query = event.target.value; syncSelection(); renderInbox(); renderReading(); renderAssistant(); loadSelectedBody(); });
  $('overview-tab').addEventListener('click', () => switchTab('overview'));
  $('reply-tab').addEventListener('click', () => switchTab('reply'));
  for (const id of ['overview-tab', 'reply-tab']) $(id).addEventListener('keydown', (event) => {
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      const tab = event.key === 'Home' ? 'overview' : event.key === 'End' ? 'reply' : state.activeTab === 'overview' ? 'reply' : 'overview';
      switchTab(tab); $(`${tab}-tab`).focus();
    }
  });
  $('mobile-menu').addEventListener('click', () => {
    const isOpen = $('sidebar').classList.toggle('mobile-open');
    $('mobile-menu').setAttribute('aria-expanded', String(isOpen));
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { closeSettings(); $('sidebar').classList.remove('mobile-open'); $('mobile-menu').setAttribute('aria-expanded', 'false'); }
    if (event.key === '/' && !state.settingsOpen && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) { event.preventDefault(); $('inbox-search').focus(); }
  });
}

function counts() {
  const result = { all: state.messages.length, high: 0 };
  for (const key of Object.keys(categories)) if (key !== 'all') result[key] = 0;
  for (const m of state.messages) {
    const analysis = analysisFor(m);
    if (analysis.category in result) result[analysis.category] += 1;
    if (analysis.priority === 'high') result.high += 1;
  }
  return result;
}

function renderNavigation() {
  const total = counts();
  $('main-navigation').replaceChildren(); $('category-navigation').replaceChildren();
  for (const [key, category] of Object.entries(categories)) {
    const target = ['all', 'needs_reply'].includes(key) ? $('main-navigation') : $('category-navigation');
    const item = button(category.label, `nav-item${state.filter === key ? ' active' : ''}`, ['all', 'needs_reply'].includes(key) ? category.icon : null, () => filterBy(key));
    if (!['all', 'needs_reply'].includes(key)) item.prepend(el('span', `category-dot ${key}`));
    item.append(el('span', 'nav-count', total[key]));
    if (state.filter === key) item.setAttribute('aria-current', 'page');
    target.append(item);
  }
  $('brief-needs-count').textContent = total.needs_reply;
  $('brief-high-count').textContent = total.high;
  const sample = state.adapter?.mode === 'demo';
  $('brief-description').textContent = total.needs_reply > 0
    ? `${total.needs_reply} ${total.needs_reply === 1 ? 'message could use' : 'messages could use'} a reply. ${sample ? 'Explore your sample inbox below.' : 'Start with the conversations that matter.'}`
    : `No messages are marked as needing a reply.${sample ? ' Explore your sample inbox below.' : ' A good moment to catch up on everything else.'}`;
  $('brief-review').hidden = total.needs_reply === 0;
  const real = !sample && state.adapter;
  const hasConnectedMailbox = state.mailStatus?.accounts?.some((account) => account.status === 'connected');
  $('mode-chip').lastElementChild.textContent = real ? hasConnectedMailbox ? isThunderbird() ? 'Thunderbird inbox' : 'Connected mailbox' : 'Mailbox needs attention' : 'Sample inbox';
  $('preview-note').textContent = real ? isThunderbird() ? 'Your Thunderbird inbox · Your decisions' : 'Mailbox changes require your review' : 'Sample messages · rule-based preview';
  const account = state.messages[0]?.account;
  $('account-name').textContent = real ? 'Your mailbox' : 'Sample workspace';
  $('account-email').textContent = typeof account === 'string' && account ? account : 'Inbox Companion';
  $('account-avatar').textContent = real && account ? initials(typeof account === 'string' ? account : '') : 'IC';
}

function filterBy(key) {
  state.filter = key;
  syncSelection();
  $('sidebar').classList.remove('mobile-open');
  $('mobile-menu').setAttribute('aria-expanded', 'false');
  renderNavigation(); renderInbox(); renderReading(); renderAssistant(); loadSelectedBody();
}

function syncSelection() {
  const visible = visibleMessages();
  if (!visible.some((m) => String(m.id) === String(state.selectedId))) state.selectedId = visible[0]?.id ?? null;
}

function loadSelectedBody() {
  const message = selectedMessage();
  if (message && !message._bodyLoaded && state.adapter && !state.busy.has(`body:${message.id}`)) void selectMessage(message.id);
}

function renderInbox() {
  const messages = visibleMessages();
  $('inbox-title').firstChild.textContent = `${categoryLabel(state.filter)} `;
  $('inbox-count').textContent = `(${messages.length})`;
  $('unread-filter').classList.toggle('active', state.unreadOnly);
  $('unread-filter').setAttribute('aria-pressed', String(state.unreadOnly));
  $('sort-description').textContent = `${messages.length} ${messages.length === 1 ? 'message' : 'messages'}`;
  const list = $('message-list'); list.replaceChildren();
  if (!messages.length) {
    const empty = el('div', 'empty-state'); empty.append(svgNode('inbox'), el('h3', '', state.query ? 'No messages found' : 'A little breathing room'), el('p', '', state.query ? 'Try another name, subject, or phrase.' : 'There are no messages in this view.'));
    if (state.query || state.unreadOnly || state.filter !== 'all') empty.append(button('Show all messages', 'secondary-button', null, () => { state.query = ''; state.unreadOnly = false; $('inbox-search').value = ''; filterBy('all'); }));
    list.append(empty); return;
  }
  for (const [index, message] of messages.entries()) {
    const active = String(message.id) === String(state.selectedId);
    const row = button('', `message-row${active ? ' selected' : ''}`, null, () => selectMessage(message.id));
    row.replaceChildren();
    row.setAttribute('aria-label', `${message.from || message.fromAddress || 'Sender'}: ${message.subject || 'No subject'}${message.unread ? ', unread' : ''}`);
    row.setAttribute('aria-pressed', String(active));
    const line = el('div', 'message-line');
    line.append(el('span', `message-avatar v${index % 5}`, initials(message.from || message.fromAddress)), el('span', 'message-sender', message.from || message.fromAddress || 'Unknown sender'), el('time', 'message-time', dateText(message.date)));
    if (message.unread) line.append(el('span', 'unread-dot'));
    row.append(line, el('div', 'message-subject', message.subject || '(No subject)'), el('p', 'message-preview', String(message.body || message.summary || '').replace(/\s+/g, ' ').trim()));
    const badges = el('div', 'message-badges');
    const analysis = analysisFor(message);
    badges.append(el('span', `badge ${analysis.category || ''}`, categoryLabel(analysis.category)));
    if (analysis.priority === 'high') badges.append(el('span', 'badge high', 'High priority'));
    if (analysis.source !== 'ai') badges.append(el('span', 'badge rule-badge', 'Rules'));
    row.append(badges); list.append(row);
  }
}

async function selectMessage(id) {
  state.selectedId = id; state.error = ''; state.selectionRevision += 1;
  const revision = state.selectionRevision;
  const bodyKey = `body:${id}`; state.busy.add(bodyKey);
  renderError(); renderInbox(); renderReading(); renderAssistant();
  try {
    const message = await state.adapter.getMessage(id);
    const idx = state.messages.findIndex((m) => String(m.id) === String(id));
    if (idx >= 0 && message) state.messages[idx] = { ...state.messages[idx], ...message, _bodyLoaded: true };
    if (revision === state.selectionRevision) { renderReading(); renderAssistant(); }
  } catch (error) { if (revision === state.selectionRevision) showError(`Could not open this message. ${error.message || ''}`); }
  finally { state.busy.delete(bodyKey); }
}

function renderReading() {
  const view = $('reading-column'); view.replaceChildren();
  const message = selectedMessage();
  if (!message) { const empty = el('div', 'panel-empty'); empty.append(svgNode('mail'), el('p', '', 'Select a message to see the whole conversation.')); view.append(empty); return; }
  const toolbar = el('div', 'reading-toolbar');
  const archive = button('', 'icon-button', 'archive', archiveCurrent); archive.setAttribute('aria-label', state.adapter?.mode === 'demo' ? 'Archive sample message' : 'Archive this email'); archive.title = 'Archive message'; archive.disabled = state.busy.has(`archive:${message.id}`);
  const prepare = button('', 'icon-button', 'reply', () => { switchTab('reply'); $('reply-intent')?.focus(); }); prepare.setAttribute('aria-label', 'Prepare a reply'); prepare.title = 'Prepare a reply';
  const review = button('', 'icon-button', 'sparkle', analyzeCurrent); review.setAttribute('aria-label', 'Review message with companion'); review.title = 'Review message'; review.disabled = state.busy.has(`analyze:${message.id}`);
  const messages = visibleMessages();
  toolbar.append(archive, prepare, el('span', 'toolbar-divider'), review, el('span', 'reading-position', `${messages.findIndex((m) => String(m.id) === String(message.id)) + 1} of ${messages.length}`));
  const body = el('div', 'message-view');
  const header = el('header', 'message-header'); header.append(el('h2', '', message.subject || '(No subject)'));
  const sender = el('div', 'sender-detail');
  sender.append(el('span', 'message-avatar', initials(message.from || message.fromAddress)));
  const meta = el('div', 'sender-meta');
  meta.append(el('p', '', message.from || message.fromAddress || 'Unknown sender'), el('span', '', message.fromAddress || ''));
  sender.append(meta, el('time', 'message-date', dateText(message.date, true)));
  header.append(sender, el('p', 'recipient-line', `To: ${Array.isArray(message.to) ? message.to.join(', ') : message.to || 'you'}`));
  body.append(header);
  if (message.bodyTruncated) body.append(el('p', 'truncation-notice', 'This long email has been shortened. Review the full message in your mailbox before preparing a reply.'));
  body.append(el('div', 'email-body', message.body || 'No plain-text content is available for this message.'));
  const footer = el('div', 'message-footer');
  const note = el('span', 'quiet-note'); note.append(svgNode('shield'), el('span', '', 'Every reply stays under your control.'));
  footer.append(note, button('Prepare reply', 'secondary-button', 'feather', () => { switchTab('reply'); $('reply-intent')?.focus(); }));
  view.append(toolbar, body, footer);
}

function switchTab(tab) {
  state.activeTab = tab;
  for (const key of ['overview', 'reply']) {
    $(`${key}-tab`).classList.toggle('active', key === tab);
    $(`${key}-tab`).setAttribute('aria-selected', String(key === tab));
    $(`${key}-tab`).tabIndex = key === tab ? 0 : -1;
    $(`${key}-panel`).hidden = key !== tab;
  }
  renderAssistant();
}

function renderAssistant() {
  const overview = $('overview-panel'); const reply = $('reply-panel'); overview.replaceChildren(); reply.replaceChildren();
  const message = selectedMessage();
  if (!message) {
    for (const panel of [overview, reply]) { const empty = el('div', 'panel-empty'); empty.append(svgNode('sparkle'), el('p', '', 'Your companion is ready when you select a message.')); panel.append(empty); }
    return;
  }
  const analysis = analysisFor(message);
  const summary = el('section', 'overview-summary');
  const kicker = el('h3', 'panel-kicker', 'The short version'); kicker.append(svgNode('sparkle'));
  const box = el('div', 'summary-box');
  box.append(el('p', '', analysis.summary || 'Review this message to get a summary and suggested category.'));
  const source = el('span', 'summary-source'); source.append(svgNode(analysis.source === 'ai' ? 'sparkle' : 'filter'), el('span', '', analysis.source === 'ai' ? 'AI-assisted summary' : 'Rule-based preview')); box.append(source);
  summary.append(kicker, box);
  const priority = el('section', 'overview-priority');
  const pRow = el('div', 'priority-row'); pRow.append(el('h3', 'priority-title', 'Suggested priority'), el('span', `badge ${analysis.priority === 'high' ? 'high' : ''}`, analysis.priority === 'high' ? 'High priority' : analysis.priority === 'low' ? 'Low priority' : 'Normal priority'));
  priority.append(pRow, el('p', 'reason-copy', analysis.reason || 'Review this message to see why it may need your attention.'), el('h3', 'panel-kicker', 'Keep it organized'));
  const selectWrap = el('div', 'category-select'); const dot = el('span', `category-dot ${analysis.category || 'updates'}`); const select = el('select'); select.setAttribute('aria-label', 'Category to apply');
  for (const [value, data] of Object.entries(categories)) if (value !== 'all') { const option = el('option', '', data.label); option.value = value; select.append(option); }
  select.value = analysis.category in categories ? analysis.category : 'updates';
  select.addEventListener('change', () => { dot.className = `category-dot ${select.value}`; });
  selectWrap.append(dot, select);
  const apply = button(state.busy.has(`category:${message.id}`) ? 'Applying…' : 'Apply category', 'secondary-button full-width', 'tag', () => applyCategory(message.id, select.value)); apply.disabled = state.busy.has(`category:${message.id}`);
  priority.append(selectWrap, apply);
  const connection = el('section', 'connection-panel');
  connection.append(el('div', 'assistant-divider'));
  const analyzing = state.busy.has(`analyze:${message.id}`);
  const analyze = button(analyzing ? 'Reviewing message…' : state.health?.aiReady ? 'Review with AI' : 'Review with rules', 'primary-button full-width', 'sparkle', analyzeCurrent); analyze.disabled = analyzing;
  connection.append(analyze);
  if (!state.health?.aiReady) {
    const note = el('div', 'ai-connection-note'); note.append(svgNode('bulb')); const copy = el('div'); copy.append(el('p', '', 'Connect an AI model for thoughtful summaries and reply drafts.'), button('Set up your companion', '', null, openSettings)); note.append(copy); connection.append(note);
  } else {
    const note = el('p', 'draft-note', 'AI can miss details. Review its suggestions before applying them.'); connection.append(note);
  }
  overview.append(summary, priority, connection);
  renderReply(message, reply);
}

function draftState(message) {
  const key = String(message.id);
  if (!state.drafts.has(key)) state.drafts.set(key, { intent: '', tone: 'professional', body: '', source: '', saved: false });
  return state.drafts.get(key);
}

function renderReply(message, panel) {
  const draft = draftState(message);
  const generation = el('div', 'reply-generation');
  if (message.bodyTruncated) generation.append(el('p', 'truncation-notice', 'This email has been shortened. Review the full message in your mailbox and include any missing details in your instructions.'));
  const intentLabel = el('label', 'control-label', 'What should your reply say?'); intentLabel.htmlFor = 'reply-intent';
  const intent = el('textarea', 'form-control intent-control'); intent.id = 'reply-intent'; intent.rows = 3; intent.placeholder = 'e.g. Thank them and ask for the revised quote'; intent.value = draft.intent;
  intent.addEventListener('input', () => { draft.intent = intent.value; const generate = $('generate-reply'); if (generate) generate.disabled = !draft.intent.trim() || state.busy.has(`draft:${message.id}`); });
  generation.append(intentLabel, intent, el('p', 'intent-help', 'Give your companion the facts and the direction. It will help find the words.'));
  const controls = el('div', 'draft-controls single-control'); const toneWrap = el('div'); const toneLabel = el('label', 'control-label', 'Your tone'); toneLabel.htmlFor = 'reply-tone'; const tone = el('select', 'form-control'); tone.id = 'reply-tone';
  for (const value of ['professional', 'friendly', 'concise']) { const option = el('option', '', value[0].toUpperCase() + value.slice(1)); option.value = value; tone.append(option); }
  tone.value = draft.tone; tone.addEventListener('change', () => { draft.tone = tone.value; }); toneWrap.append(toneLabel, tone); controls.append(toneWrap); generation.append(controls);
  const drafting = state.busy.has(`draft:${message.id}`);
  const generate = button(drafting ? 'Preparing your reply…' : draft.body ? 'Prepare another draft' : 'Prepare a draft', 'primary-button full-width', 'sparkle', generateDraft); generate.id = 'generate-reply'; generate.disabled = drafting || !draft.intent.trim(); generation.append(generate);
  if (!state.health?.aiReady) {
    const note = el('div', 'ai-connection-note'); note.style.marginTop = '12px'; note.append(svgNode('bulb')); const text = el('div'); text.append(el('p', '', 'Reply drafts need a connected AI model. Your instructions stay here while you set it up.'), button('Connect your model', '', null, openSettings)); note.append(text); generation.append(note);
  }
  const result = el('div', 'reply-result');
  if (!draft.body) {
    const empty = el('div', 'draft-empty'); empty.append(svgNode('feather'), el('strong', '', 'Your words, with a little help.'), el('p', '', 'Tell your companion what you want to say, then review your draft here.')); result.append(empty);
    result.append(el('p', 'draft-note', 'Nothing is sent automatically. You can edit every word.'));
  } else {
    const label = el('label', 'panel-kicker', 'Your editable draft'); label.htmlFor = 'draft-body';
    const editor = el('textarea', 'draft-editor'); editor.id = 'draft-body'; editor.value = draft.body; editor.setAttribute('aria-label', 'Edit prepared reply');
    editor.addEventListener('input', () => { draft.body = editor.value; draft.saved = false; const save = $('save-draft'); if (save) { save.disabled = !draft.body.trim() || state.busy.has(`save:${message.id}`); save.querySelector('.label').textContent = saveDraftLabel(); } });
    result.append(label, editor, el('p', 'draft-note', 'AI-assisted draft. Check names, facts, and commitments before you use it.'));
    const actions = el('div', 'draft-actions');
    const save = button(state.busy.has(`save:${message.id}`) ? 'Saving…' : draft.saved ? 'Draft saved' : saveDraftLabel(), 'secondary-button', state.adapter.mode === 'demo' ? 'copy' : 'mail', saveDraft); save.id = 'save-draft'; save.disabled = !draft.body.trim() || state.busy.has(`save:${message.id}`) || (draft.saved && state.adapter.mode === 'live'); actions.append(save); result.append(actions);
  }
  panel.append(generation, result);
}

async function analyzeCurrent() {
  const message = selectedMessage(); if (!message || !state.adapter) return;
  const key = `analyze:${message.id}`; if (state.busy.has(key)) return;
  state.busy.add(key); state.error = ''; renderError(); renderAssistant(); renderReading();
  try {
    const fullMessage = await state.adapter.getMessage(message.id);
    const index = state.messages.findIndex((m) => String(m.id) === String(message.id));
    if (index >= 0) state.messages[index] = { ...state.messages[index], ...fullMessage, _bodyLoaded: true };
    const analysis = await state.adapter.analyze(fullMessage);
    state.analyses.set(String(message.id), analysis);
    renderNavigation(); renderInbox();
    toast(analysis.source === 'ai' ? 'Summary and suggestions are ready for your review.' : 'Rule-based review is ready. Connect an AI model for a deeper review.');
  } catch (error) { showError(`Could not review this message. ${error.message || ''}`); }
  finally { state.busy.delete(key); renderAssistant(); renderReading(); }
}

async function applyCategory(id, category) {
  const key = `category:${id}`; if (!state.adapter || state.busy.has(key)) return;
  state.busy.add(key); state.error = ''; renderError(); renderAssistant();
  try {
    await state.adapter.applyCategory(id, category);
    const message = state.messages.find((m) => String(m.id) === String(id));
    if (message) message.category = category;
    const analysis = state.analyses.get(String(id)); if (analysis) analysis.category = category;
    syncSelection(); renderNavigation(); renderInbox(); renderReading(); loadSelectedBody();
    toast(state.adapter.mode === 'demo' ? `Sample message categorized as ${categoryLabel(category).toLowerCase()}.` : `Category applied: ${categoryLabel(category)}.`);
  } catch (error) { showError(`Could not apply this category. ${error.message || ''}`); }
  finally { state.busy.delete(key); renderAssistant(); }
}

async function archiveCurrent() {
  const message = selectedMessage(); if (!message || !state.adapter) return;
  const key = `archive:${message.id}`; if (state.busy.has(key)) return;
  state.busy.add(key); state.error = ''; renderError(); renderReading();
  try {
    await state.adapter.archive(message.id);
    state.messages = state.messages.filter((m) => String(m.id) !== String(message.id));
    state.selectedId = null; syncSelection(); renderNavigation(); renderInbox(); renderReading(); renderAssistant(); loadSelectedBody();
    toast(state.adapter.mode === 'demo' ? 'Sample message archived. Your real inbox is unchanged.' : 'Email moved to your archive.');
  } catch (error) { showError(`Could not archive this email. ${error.message || ''}`); }
  finally { state.busy.delete(key); renderReading(); }
}

async function generateDraft() {
  const message = selectedMessage(); if (!message || !state.adapter) return;
  const draft = draftState(message); if (!draft.intent.trim()) return;
  if (!state.health?.aiReady) { showError('Connect an AI model in settings before preparing a reply. Your reply instructions have been kept.'); openSettings(); return; }
  const key = `draft:${message.id}`; if (state.busy.has(key)) return;
  state.busy.add(key); state.error = ''; renderError(); renderAssistant();
  try {
    const fullMessage = await state.adapter.getMessage(message.id);
    const index = state.messages.findIndex((m) => String(m.id) === String(message.id));
    if (index >= 0) state.messages[index] = { ...state.messages[index], ...fullMessage, _bodyLoaded: true };
    const result = await state.adapter.draft(fullMessage, { intent: draft.intent.trim(), tone: draft.tone });
    if (!result?.body || result.source !== 'ai') throw new Error('The model did not return an AI-assisted draft.');
    draft.body = result.body; draft.source = result.source; draft.saved = false;
    toast('Your draft is ready. Give it a read and make it yours.');
  } catch (error) { showError(`Could not prepare a reply. ${error.message || ''}`); }
  finally { state.busy.delete(key); renderAssistant(); renderReading(); }
}

async function saveDraft() {
  const message = selectedMessage(); if (!message || !state.adapter) return;
  const draft = draftState(message); if (!draft.body.trim()) return;
  if (draft.saved && state.adapter.mode === 'live') return;
  const key = `save:${message.id}`; if (state.busy.has(key)) return;
  state.busy.add(key); state.error = ''; renderError(); renderAssistant();
  try {
    if (state.adapter.mode === 'demo') {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard access is unavailable. Select the draft text and copy it with your keyboard.');
      await navigator.clipboard.writeText(draft.body);
      toast('Draft copied. Nothing has been sent.');
    } else {
      const savedBody = draft.body;
      await state.adapter.openReply(message.id, savedBody);
      draft.saved = draft.body === savedBody;
      toast(isThunderbird() ? 'Reply saved in Thunderbird and opened for your review. Nothing has been sent.' : 'Reply saved to your mailbox drafts. Nothing has been sent.');
    }
  } catch (error) { showError(`Could not ${state.adapter.mode === 'demo' ? 'copy' : 'save'} this draft. ${error.message || ''}`); }
  finally { state.busy.delete(key); renderAssistant(); }
}

function renderConnection() {
  const ready = Boolean(state.health?.aiReady);
  $('connection-pill').classList.toggle('ready', ready);
  $('connection-text').textContent = ready ? 'AI connected' : 'Connect your AI';
  $('connection-pill').setAttribute('aria-label', ready ? 'AI is connected. Open connection settings' : 'Connect your AI model in settings');
}

async function refresh({ initial = false } = {}) {
  if (!state.adapter || state.busy.has('refresh')) return;
  state.busy.add('refresh'); $('refresh-button').disabled = true; state.error = ''; renderError();
  try {
    const [messages, health] = await Promise.allSettled([state.adapter.listMessages(), state.adapter.health()]);
    if (health.status === 'fulfilled') { state.health = health.value; if (['demo', 'live'].includes(health.value.mode)) state.adapter.mode = health.value.mode; }
    else state.health = { aiReady: false, detail: health.reason?.message || 'The AI service could not be reached.' };
    if (state.adapter.mailStatus) {
      try { state.mailStatus = await state.adapter.mailStatus(); }
      catch (error) { state.mailStatus = { accounts: [{ name: 'Mailbox', status: 'error', detail: error.message || 'Could not check the mailbox connection.' }] }; }
    }
    renderError(); renderNavigation(); renderConnection();
    if (messages.status === 'rejected') throw messages.reason;
    state.messages = messages.value.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    syncSelection(); renderNavigation(); renderInbox(); renderReading(); renderConnection(); renderAssistant();
    if (!initial) toast('Inbox refreshed.');
    if (state.selectedId != null) await selectMessage(state.selectedId);
  } catch (error) { showError(`Could not refresh your inbox. ${error.message || ''}`); if (initial) { state.messages = []; renderInbox(); renderReading(); renderAssistant(); } }
  finally { state.busy.delete('refresh'); $('refresh-button').disabled = false; }
}

function showError(message) { state.error = message; renderError(); }
function renderError() {
  const holder = $('error-container'); holder.replaceChildren();
  const failed = state.mailStatus?.accounts?.filter((account) => account.status === 'error') || [];
  if (failed.length) {
    const warning = el('div', 'error-banner mailbox-warning'); warning.setAttribute('role', 'alert');
    warning.append(svgNode('warning'), el('span', '', `Some mailboxes could not be loaded. ${failed.map((account) => `${account.name || account.id || 'Mailbox'}: ${account.detail || 'Connection failed.'}`).join(' ')}`), button('Settings', '', null, openSettings)); holder.append(warning);
  }
  if (!state.error) return;
  const error = el('div', 'error-banner'); error.setAttribute('role', 'alert'); error.append(svgNode('warning'), el('span', '', state.error));
  const dismiss = button('×', '', null, () => { state.error = ''; renderError(); }); dismiss.setAttribute('aria-label', 'Dismiss error'); error.append(dismiss); holder.append(error);
}

function toast(message) {
  clearTimeout(state.toastTimer);
  const holder = $('toast-container'); holder.replaceChildren(); const item = el('div', 'toast'); item.append(svgNode('check'), el('span', '', message)); holder.append(item);
  state.toastTimer = setTimeout(() => holder.replaceChildren(), 5500);
}

let settingsReturnFocus;
async function openSettings() {
  if (state.settingsOpen) return;
  state.settingsOpen = true; settingsReturnFocus = document.activeElement; renderSettings();
  try {
    if (state.adapter) {
      const [health, settings] = await Promise.allSettled([state.adapter.health(), state.adapter.getSettings()]);
      if (health.status === 'fulfilled') state.health = health.value;
      if (settings.status === 'fulfilled') state.settings = settings.value;
      renderConnection(); renderAssistant(); if (state.settingsOpen) renderSettings();
    }
  } catch (_) { /* The settings panel already explains how to connect the service. */ }
}

function closeSettings() {
  if (!state.settingsOpen) return;
  state.settingsOpen = false; $('modal-container').replaceChildren(); document.body.style.overflow = '';
  if (settingsReturnFocus?.isConnected) settingsReturnFocus.focus();
}

function renderSettings() {
  const holder = $('modal-container'); holder.replaceChildren(); document.body.style.overflow = 'hidden';
  const overlay = el('div', 'modal-overlay'); overlay.addEventListener('click', (event) => { if (event.target === overlay) closeSettings(); });
  const modal = el('section', 'settings-modal'); modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true'); modal.setAttribute('aria-labelledby', 'settings-title');
  const top = el('div', 'modal-top'); const title = el('h2', '', 'Make it your companion'); title.id = 'settings-title'; const close = button('', 'icon-button', 'close', closeSettings); close.setAttribute('aria-label', 'Close settings'); top.append(title, close);
  const native = isThunderbird();
  modal.append(top, el('p', 'modal-intro', native ? 'Your Thunderbird accounts bring the email. Pair your local companion service to bring the AI. You review every action.' : 'Connect your mailbox and AI model to move from a sample inbox to your everyday email. Your credentials stay on the server.'));
  const mail = el('section', 'connection-status');
  const hasConnectedMailbox = state.mailStatus?.accounts?.some((account) => account.status === 'connected');
  const mailLine = el('div', 'settings-status-line'); const mailTitle = el('strong', '', 'Your mailbox'); mailTitle.prepend(svgNode('mail')); mailLine.append(mailTitle, el('span', `badge ${hasConnectedMailbox ? 'finance' : ''}`, state.adapter?.mode === 'live' ? hasConnectedMailbox ? 'Connected' : 'Needs attention' : 'Sample inbox'));
  if (native) {
    mail.append(el('p', '', 'Your messages come from the accounts already configured in Thunderbird. Thunderbird manages the connection and your email credentials.'));
    mail.append(el('p', '', 'Add or adjust your email accounts in Thunderbird’s Account Settings, then refresh this inbox. Archive and save draft actions happen only when you choose them. Categories are stored locally by Inbox Companion.'));
    if (typeof state.adapter.openAccountSettings === 'function') mail.append(button('Open Thunderbird account settings', 'secondary-button settings-refresh', 'settings', async () => {
      try { await state.adapter.openAccountSettings(); }
      catch (error) { closeSettings(); showError(`Could not open Thunderbird account settings. ${error.message || ''}`); }
    }));
  } else {
    mail.append(el('p', '', state.adapter?.mode === 'live' ? 'Messages are loaded from your configured mailbox. Archive and save draft actions change that mailbox only when you choose them. Categories are stored locally in this app.' : 'You are exploring sample messages. Connect an IMAP account on the server to load your own inbox.'));
    const hint = el('p', 'mail-config-hint'); hint.append(document.createTextNode('Add '), el('code', '', 'IMAP_HOST'), document.createTextNode(', '), el('code', '', 'IMAP_USER'), document.createTextNode(', and '), el('code', '', 'IMAP_PASSWORD'), document.createTextNode(' to the server’s local .env file, or configure MAIL_ACCOUNTS_FILE for multiple accounts. Restart the service, then refresh your inbox.'));
    mail.append(hint, el('p', '', 'See the project README for your provider’s settings and app-password requirements. Enter credentials locally; never paste them into this chat.'));
  }
  if (state.mailStatus?.accounts?.length) {
    const accountStatuses = el('div', 'mail-account-status');
    for (const account of state.mailStatus.accounts) {
      const row = el('div', account.status === 'error' ? 'mail-error' : ''); row.append(el('strong', '', account.name || account.id || 'Mailbox'), el('span', '', account.detail || account.status)); accountStatuses.append(row);
    }
    mail.append(accountStatuses);
  }
  const ai = el('section', 'connection-status');
  const aiLine = el('div', 'settings-status-line'); const aiTitle = el('strong', '', 'Your AI model'); aiTitle.prepend(svgNode('sparkle')); aiLine.append(aiTitle, el('span', `badge ${state.health?.aiReady ? 'finance' : ''}`, state.health?.aiReady ? 'Connected' : 'Setup needed')); ai.append(aiLine);
  const provider = state.health?.provider; const model = state.health?.model;
  if (provider || model) ai.append(el('p', '', [provider, model].filter(Boolean).join(' · ')));
  if (state.health?.detail) ai.append(el('p', '', String(state.health.detail)));
  if (native) {
    if (state.settings?.serviceUrl) ai.append(el('p', '', `Companion service: ${state.settings.serviceUrl}`));
    ai.append(el('p', '', state.settings?.paired ? 'A companion service access token has been saved in the add-on settings.' : 'Pair the add-on with your local companion service in its connection options.'));
    if (typeof state.adapter.openSettings === 'function') ai.append(button('Open companion connection options', 'secondary-button settings-refresh', 'settings', async () => {
      try { await state.adapter.openSettings(); }
      catch (error) { closeSettings(); showError(`Could not open the add-on connection options. ${error.message || ''}`); }
    }));
  }
  if (!state.health?.aiReady) {
    ai.append(el('p', '', 'Connect OpenAI through your local companion service for summaries and reply drafts. The API key stays in the service’s private configuration.'));
    const list = el('ol', 'setup-steps');
    const modelStep = el('li'); modelStep.append(document.createTextNode('Add your OpenAI API key as '), el('code', '', 'APP_AI_KEY'), document.createTextNode(' in the companion service’s private local '), el('code', '', '.env'), document.createTextNode(' file. Use '), el('code', '', 'AI_PROVIDER=openai'), document.createTextNode(' and '), el('code', '', 'AI_MODEL=gpt-4.1-mini'), document.createTextNode('.'));
    const appStep = el('li'); appStep.append(document.createTextNode(native ? 'Start the local AI companion service with ' : 'Start this app with '), el('code', '', native ? 'npm start' : 'npm run dev'), document.createTextNode(native ? '.' : ', then check the connection.'));
    list.append(modelStep, appStep);
    if (native) {
      const pairStep = el('li'); pairStep.append(document.createTextNode('Open the companion connection options and enter its connection token from '), el('code', '', '.local/session-token'), document.createTextNode('. Then check the connection.')); list.append(pairStep);
    }
    ai.append(list);
    if (native) ai.append(el('p', '', 'The add-on uses a separate pairing token to access your local companion service. Keep your OpenAI API key in the service’s private configuration; never enter it in the add-on.'));
    ai.append(el('p', '', 'Ollama is an optional local alternative. Set AI_PROVIDER=ollama and AI_MODEL=qwen3:4b, then run ollama pull qwen3:4b and ollama serve. See the README for complete setup.'));
  }
  const check = button(state.busy.has('health') ? 'Checking…' : 'Check connection', 'secondary-button settings-refresh', 'refresh', checkHealth); check.disabled = state.busy.has('health'); ai.append(check);
  const footer = el('div', 'modal-footer'); footer.append(button('Back to my inbox', 'primary-button', 'arrow', closeSettings));
  modal.append(mail, ai, el('p', 'settings-note', 'Rules can help organize your inbox before AI is connected. Replies always require a live model and your instructions.'), footer);
  overlay.append(modal); holder.append(overlay); close.focus();
  modal.addEventListener('keydown', (event) => {
    if (event.key !== 'Tab') return;
    const focusable = [...modal.querySelectorAll('button,a,input,select,textarea,[tabindex="0"]')].filter((element) => !element.disabled);
    const first = focusable[0]; const last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  });
}

async function checkHealth() {
  if (!state.adapter || state.busy.has('health')) return;
  state.busy.add('health'); renderSettings();
  try {
    state.health = await state.adapter.health();
    toast(state.health.aiReady ? 'Your AI model is connected.' : 'Connection checked. Follow the setup steps to finish connecting.');
  } catch (error) { state.health = { aiReady: false, detail: error.message || 'Could not reach the AI service.' }; }
  finally { state.busy.delete('health'); renderConnection(); renderAssistant(); if (state.settingsOpen) renderSettings(); }
}

shell();
try {
  const { createAdapter } = await import('./adapter.js');
  state.adapter = await createAdapter();
  await refresh({ initial: true });
} catch (error) {
  showError(`The inbox service could not be started. ${error.message || ''} Start the local app service and refresh this page.`);
  state.messages = []; renderNavigation(); renderInbox(); renderReading(); renderAssistant(); renderConnection();
}
