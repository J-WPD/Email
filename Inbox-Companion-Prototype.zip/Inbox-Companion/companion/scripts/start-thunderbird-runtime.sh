#!/usr/bin/env bash
# Optional local native validation, using a dedicated development profile only.
# Runs in the foreground and cleans up only child processes it started.
set -euo pipefail
umask 077

script_directory="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repository_directory="$(cd -- "$script_directory/.." && pwd -P)"
runtime_directory="$repository_directory/.local/thunderbird-runtime"
runtime_root="$runtime_directory/root"
profile_directory="$runtime_directory/profile"
marionette_port=2828
requested_display=''
synthetic_ci=false
while (($#)); do
  case "$1" in
    --profile-name)
      [[ $# -ge 2 && "$2" =~ ^[A-Za-z0-9_-]{1,60}$ ]] || { printf '%s\n' 'Use a short development profile name.' >&2; exit 1; }
      profile_directory="$runtime_directory/profiles/$2"
      shift 2 ;;
    --marionette-port)
      [[ $# -ge 2 && "$2" =~ ^[0-9]{4,5}$ ]] || { printf '%s\n' 'Use a localhost Marionette port between 1024 and 65535.' >&2; exit 1; }
      marionette_port="$2"
      [[ "$marionette_port" -ge 1024 && "$marionette_port" -le 65535 ]] || exit 1
      shift 2 ;;
    --display)
      [[ $# -ge 2 && "$2" =~ ^[0-9]{1,3}$ ]] || { printf '%s\n' 'Use a numeric Xvfb display.' >&2; exit 1; }
      requested_display="$2"
      shift 2 ;;
    --synthetic-ci)
      synthetic_ci=true
      shift ;;
    --help)
      printf '%s\n' 'Usage: scripts/start-thunderbird-runtime.sh [--profile-name NAME] [--marionette-port PORT] [--display NUMBER] [--synthetic-ci]'
      printf '%s\n' '--synthetic-ci: isolated synthetic fixtures only; disables the nested content sandbox for this cloud invocation. Never use real mail.'
      exit 0 ;;
    *) printf 'Unknown native runtime option: %s\n' "$1" >&2; exit 1 ;;
  esac
done

"$script_directory/setup-thunderbird-runtime.sh"
for command in python3 xauth flock; do
  command -v "$command" >/dev/null || { printf 'Required native startup tool is missing: %s\n' "$command" >&2; exit 1; }
done

python3 - "$runtime_directory" "$profile_directory" "$marionette_port" <<'PY'
import ast
import configparser
import re
import socket
import sys
from pathlib import Path

base, profile, port = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
if profile.is_symlink() or not profile.resolve().is_relative_to(base.resolve()):
    raise SystemExit('Development profiles must stay inside the ignored native runtime directory; live profile symlinks are not supported.')
marker = profile / '.inbox-companion-development-profile'
if profile.exists() and not marker.exists() and any(profile.iterdir()):
    raise SystemExit('Refusing to use an existing unmarked profile. Choose a fresh --profile-name.')
profile.mkdir(parents=True, exist_ok=True, mode=0o700)
if not marker.exists():
    marker.write_text('Isolated Inbox Companion native development profile.\n')
user_prefs = profile / 'user.js'
# Account protocols can also come from custom providers or user.js overrides.
# Permit only local-folder servers, regardless of which preference file wins.
string_literal = r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*' '''.strip()
comments_or_strings = re.compile(f'({string_literal})|//[^\\n]*|/\\*[\\s\\S]*?\\*/')
preference_calls = re.compile(
    r'\b(?:user_pref|pref|sticky_pref)\s*\(\s*(' + string_literal + r')\s*,\s*(.*?)\s*\)\s*;',
    re.S,
)
for preference_file in [profile / 'prefs.js', user_prefs]:
    if not preference_file.exists():
        continue
    source = comments_or_strings.sub(lambda match: match.group(1) or '', preference_file.read_text())
    for key_literal, value_literal in preference_calls.findall(source):
        try:
            key = ast.literal_eval(key_literal)
        except (SyntaxError, ValueError):
            continue
        if not isinstance(key, str) or not re.fullmatch(r'mail\.server\..+\.type', key):
            continue
        try:
            server_type = ast.literal_eval(value_literal)
        except (SyntaxError, ValueError):
            server_type = None
        if server_type != 'none':
            raise SystemExit('This development profile contains a non-local mail server protocol. Only local-folder type none is allowed; choose a fresh --profile-name for isolated native validation.')
if user_prefs.exists():
    matching_port = re.search(r'user_pref\("marionette\.port",\s*(\d+)\)', user_prefs.read_text())
    if not matching_port or int(matching_port[1]) != port:
        raise SystemExit('The existing development profile uses a different Marionette port. Choose a fresh --profile-name.')
else:
    user_prefs.write_text('\n'.join([
        f'user_pref("marionette.port", {port});',
        'user_pref("mailnews.start_page.enabled", false);',
        'user_pref("mail.provider.enabled", false);',
        'user_pref("mail.provider.suppress_dialog_on_startup", true);',
        'user_pref("datareporting.healthreport.uploadEnabled", false);',
        'user_pref("datareporting.policy.dataSubmissionEnabled", false);',
        'user_pref("toolkit.telemetry.enabled", false);',
        'user_pref("extensions.autoDisableScopes", 0);',
        'user_pref("extensions.enabledScopes", 15);',
    ]) + '\n')
# Marionette binds localhost by default. Fail if another process already owns
# the requested port rather than attaching to or stopping that process.
with socket.socket() as check:
    try:
        check.bind(('127.0.0.1', port))
    except OSError:
        raise SystemExit('The requested localhost Marionette port is in use. Choose another --marionette-port.')
for name in ['cache', 'config', 'data', 'run']:
    (base / name).mkdir(exist_ok=True, mode=0o700)
(base / 'run').chmod(0o700)
# Stock application.ini and binaries remain untouched. -app is Mozilla's
# supported metadata override. Profile=. reuses the existing registry parent
# on read-only cloud hosts, while --profile keeps all actual test data local.
stock = base / 'root/usr/lib/thunderbird/application.ini'
override = stock.with_name('test-application.ini')
desired = stock.read_text().replace('Profile=Thunderbird', 'Profile=.')
if override.exists():
    actual_config, wanted_config = configparser.ConfigParser(), configparser.ConfigParser()
    actual_config.read(override)
    wanted_config.read_string(desired)
    if dict(actual_config) != dict(wanted_config):
        raise SystemExit('The existing test application override differs from the verified runtime metadata; inspect it before continuing.')
else:
    override.write_text(desired)
PY

exec 9>"$profile_directory/.native-helper.lock"
flock -n 9 || { printf '%s\n' 'This development profile is already being started by another helper.' >&2; exit 1; }

display_number=''
if [[ -n "$requested_display" ]]; then
  display_candidates=("$requested_display")
else
  display_candidates=({94..114})
fi
for candidate in "${display_candidates[@]}"; do
  if [[ ! -e "/tmp/.X11-unix/X$candidate" && ! -e "/tmp/.X$candidate-lock" ]]; then
    display_number="$candidate"
    break
  fi
done
[[ -n "$display_number" ]] || { printf '%s\n' 'No requested Xvfb display is free; existing displays were left untouched.' >&2; exit 1; }

display_authority="$(mktemp "$runtime_directory/.Xauthority.XXXXXXXX")"
xvfb_log="$(mktemp "$runtime_directory/xvfb.XXXXXXXX.log")"
display_cookie="$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
xauth -f "$display_authority" add ":$display_number" . "$display_cookie"
unset display_cookie
xvfb_pid=''
native_pid=''
cleanup_children() {
  trap - EXIT INT TERM
  if [[ -n "$native_pid" ]]; then kill -TERM "$native_pid" 2>/dev/null || true; wait "$native_pid" 2>/dev/null || true; fi
  if [[ -n "$xvfb_pid" ]]; then kill -TERM "$xvfb_pid" 2>/dev/null || true; wait "$xvfb_pid" 2>/dev/null || true; fi
  rm -f -- "$display_authority"
}
trap cleanup_children EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

"$runtime_root/usr/bin/Xvfb" ":$display_number" -screen 0 1440x1080x24 -nolisten tcp -auth "$display_authority" >"$xvfb_log" 2>&1 &
xvfb_pid=$!
python3 - "$display_number" "$xvfb_pid" "$xvfb_log" <<'PY'
import os
import sys
import time
from pathlib import Path
display, pid, log = sys.argv[1], int(sys.argv[2]), Path(sys.argv[3])
for _ in range(50):
    if Path(f'/tmp/.X11-unix/X{display}').exists():
        break
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        raise SystemExit(f'The new Xvfb process failed. See {log}.')
    time.sleep(0.1)
else:
    raise SystemExit(f'The new Xvfb process did not become ready. See {log}.')
PY

printf 'Starting isolated Thunderbird on display :%s; Marionette is local at 127.0.0.1:%s.\n' "$display_number" "$marionette_port"
printf 'Development profile: %s\n' "$profile_directory"
native_environment=(env -u MOZ_DISABLE_CONTENT_SANDBOX)
if [[ "$synthetic_ci" == true ]]; then
  # Only for trusted fixtures inside the managed cloud sandbox: its read-only
  # /proc prevents Gecko from creating a second user-namespace sandbox. Never
  # apply this opt-in workaround to Thunderbird profiles containing real mail.
  [[ -f "$profile_directory/.inbox-companion-development-profile" ]] || exit 1
  native_environment+=(MOZ_DISABLE_CONTENT_SANDBOX=1)
  printf '%s\n' 'Synthetic CI fixture mode: nested content sandbox disabled for this invocation; network mail accounts are refused.'
fi
DISPLAY=":$display_number" XAUTHORITY="$display_authority" \
LD_LIBRARY_PATH="$runtime_root/usr/lib/x86_64-linux-gnu:$runtime_root/usr/lib/thunderbird" \
XDG_CACHE_HOME="$runtime_directory/cache" XDG_CONFIG_HOME="$runtime_directory/config" \
XDG_DATA_HOME="$runtime_directory/data" XDG_RUNTIME_DIR="$runtime_directory/run" \
MOZ_CRASHREPORTER_DISABLE=1 MOZ_MARIONETTE=1 \
  "${native_environment[@]}" "$runtime_root/usr/lib/thunderbird/thunderbird-bin" \
  -app "$runtime_root/usr/lib/thunderbird/test-application.ini" \
  --new-instance --profile "$profile_directory" --marionette --remote-allow-system-access &
native_pid=$!
wait "$native_pid"
