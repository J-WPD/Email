import { mkdir, readFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(await readFile(resolve(root, 'thunderbird/manifest.json'), 'utf8'));
if (manifest.manifest_version !== 2 || !manifest.browser_specific_settings?.gecko?.id) throw new Error('A valid Thunderbird add-on manifest is required.');
for (const file of ['web/index.html', 'web/styles.css', 'web/app.js', 'thunderbird/adapter.js', 'thunderbird/background.js', 'thunderbird/options.html', 'thunderbird/options.js', 'thunderbird/options.css']) await access(resolve(root, file));
await mkdir(resolve(root, '.local'), { recursive: true, mode: 0o700 });
const python = `
import pathlib, sys, zipfile
root = pathlib.Path(sys.argv[1])
target = root / '.local' / 'inbox-companion.xpi'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ['manifest.json', 'background.js', 'options.html', 'options.js', 'options.css']:
        archive.write(root / 'thunderbird' / name, name)
    for name in ['index.html', 'styles.css', 'app.js']:
        archive.write(root / 'web' / name, 'web/' + name)
    archive.write(root / 'thunderbird' / 'adapter.js', 'web/adapter.js')
    for source in sorted((root / 'thunderbird').glob('*.svg')):
        archive.write(source, source.name)
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('Add-on archive verification failed.')
print('Packaged .local/inbox-companion.xpi (Thunderbird add-on).')
`;
const result = spawnSync('python3', ['-c', python, root], { cwd: root, stdio: 'inherit' });
if (result.status !== 0) process.exit(result.status ?? 1);
