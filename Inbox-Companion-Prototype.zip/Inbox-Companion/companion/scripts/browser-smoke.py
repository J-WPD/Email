"""Browser checks with a SIMULATED model, never a real mailbox or AI credential.

Requires Python Playwright and a Chromium executable. This is an optional
development check, separate from npm test. Run from the repository root.
"""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import urlopen

from playwright.sync_api import sync_playwright, expect


class SimulatedModel(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, value):
        payload = json.dumps(value).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        self.reply({'models': [{'name': 'browser-fixture'}]})

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        properties = payload['format']['properties']
        result = {'body': 'Thanks, Sarah. Could you send the revised quote?'} if 'body' in properties else {
            'summary': 'Sarah is asking you to review the project scope.',
            'category': 'needs_reply', 'priority': 'normal',
            'reason': 'A response is requested.'
        }
        self.reply({'message': {'content': json.dumps(result)}})


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--chromium', default='/usr/bin/chromium')
    parser.add_argument('--screenshot')
    args = parser.parse_args()
    repo = Path(__file__).resolve().parent.parent
    model = ThreadingHTTPServer(('127.0.0.1', 0), SimulatedModel)
    threading.Thread(target=model.serve_forever, daemon=True).start()
    with socket.socket() as reservation:
        reservation.bind(('127.0.0.1', 0))
        port = reservation.getsockname()[1]
    with tempfile.TemporaryDirectory(prefix='inbox-browser-') as directory:
        environment = dict(os.environ)
        for key in ['IMAP_HOST', 'IMAP_USER', 'IMAP_PASSWORD', 'MAIL_ACCOUNTS_FILE', 'APP_AI_KEY']:
            environment.pop(key, None)
        environment.update(PORT=str(port), STATE_DIRECTORY=directory, AI_PROVIDER='ollama', AI_MODEL='browser-fixture', OLLAMA_URL=f'http://127.0.0.1:{model.server_port}')
        process = subprocess.Popen(['node', 'server/index.js'], cwd=repo, env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        address = f'http://127.0.0.1:{port}'
        try:
            for _ in range(50):
                if process.poll() is not None:
                    raise RuntimeError('Browser fixture server did not start.')
                try:
                    urlopen(address, timeout=1).close()
                    break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError('Browser fixture server readiness timed out.')
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=args.chromium, headless=True, args=['--no-sandbox'])
                page = browser.new_page(viewport={'width': 1600, 'height': 1050}, permissions=['clipboard-read', 'clipboard-write'])
                errors, requests = [], []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.on('request', lambda request: requests.append(request.url))
                page.goto(address, wait_until='networkidle')
                expect(page.get_by_role('heading', name='A calmer inbox starts here.')).to_be_visible()
                expect(page.locator('.message-row')).to_have_count(7)
                expect(page.locator('.email-body')).to_contain_text('Hi Alex')
                page.get_by_role('searchbox', name='Search messages').fill('invoice')
                expect(page.locator('.message-row')).to_have_count(1)
                expect(page.locator('.email-body')).to_contain_text('£49')
                page.get_by_role('searchbox', name='Search messages').fill('')
                page.get_by_role('button', name='Unread only', exact=True).click()
                expect(page.locator('.message-row')).to_have_count(3)
                page.get_by_role('button', name='Unread only', exact=True).click()
                page.locator('.message-row').first.click()
                page.get_by_role('button', name='Review with AI', exact=True).click()
                expect(page.locator('.summary-box')).to_contain_text('Sarah is asking you')
                expect(page.locator('.summary-box')).to_contain_text('AI-assisted summary')
                page.get_by_role('combobox', name='Category to apply').select_option('personal')
                page.get_by_role('button', name='Apply category', exact=True).click()
                expect(page.locator('.message-row').first).to_contain_text('Personal')
                page.get_by_role('tab', name='Prepare reply').click()
                expect(page.get_by_role('button', name='Prepare a draft', exact=True)).to_be_disabled()
                page.get_by_label('What should your reply say?').fill('Thank Sarah and ask for the revised quote.')
                page.get_by_role('button', name='Prepare a draft', exact=True).click()
                expect(page.get_by_role('textbox', name='Edit prepared reply')).to_have_value('Thanks, Sarah. Could you send the revised quote?')
                page.get_by_role('textbox', name='Edit prepared reply').fill('Thanks, Sarah. Could you share the final quote, please?')
                page.get_by_role('button', name='Copy draft', exact=True).click()
                assert page.evaluate('navigator.clipboard.readText()') == 'Thanks, Sarah. Could you share the final quote, please?'
                page.get_by_role('button', name='Archive sample message', exact=True).click()
                expect(page.locator('.message-row')).to_have_count(6)
                expect(page.locator('.email-body')).to_contain_text('Hi Alex')
                page.get_by_role('button', name='Open settings', exact=True).click()
                expect(page.get_by_role('dialog')).to_be_visible()
                page.keyboard.press('Escape')
                expect(page.get_by_role('dialog')).to_have_count(0)
                assert not errors, errors
                assert all(url.startswith(address) for url in requests), 'Unexpected external browser requests'
                page.set_viewport_size({'width': 390, 'height': 844})
                assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Mobile page overflows horizontally'
                page.get_by_role('button', name='Toggle inbox navigation').click()
                expect(page.get_by_role('navigation').first).to_be_visible()
                page.keyboard.press('Escape')
                if args.screenshot:
                    page.set_viewport_size({'width': 1600, 'height': 1050})
                    page.screenshot(path=args.screenshot, full_page=True)
                browser.close()
                print('Browser checks passed: search, unread filter, category, SIMULATED AI summary/draft, editable draft, clipboard, archive, settings, and mobile layout. No live account or actual model was tested.')
        finally:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            model.shutdown()


if __name__ == '__main__':
    run()
