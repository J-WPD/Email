#!/usr/bin/env python3
"""Exercise the packaged add-on against an already running synthetic Thunderbird.

Requires marionette-driver in the separate native-validation Python environment.
The runtime must use a task-owned profile and contain only reserved-address Local
Folders fixtures. This script never signs in, connects an account, or sends mail.
Thunderbird does not expose its tabs through Marionette's Firefox TabManager, so
content commands use the existing MarionetteCommands actor for the add-on tab.
"""

import argparse
import json
from datetime import datetime, timezone
from email.utils import format_datetime
from pathlib import Path
import time

from marionette_driver.addons import Addons
from marionette_driver.marionette import Marionette

ROOT = Path(__file__).resolve().parents[1]
ADDON_ID = 'inbox-companion@j-wpd.email'
SUBJECT = 'Native smoke: review the project scope'
FIXTURE_ID = 'inbox-native-smoke@example.com'


class NativeSmoke:
    def __init__(self, port):
        self.driver = Marionette(host='127.0.0.1', port=port)
        self.driver.start_session()
        self.driver.set_context('chrome')
        self.driver.timeout.script = 30

    def chrome(self, script, args=None):
        return self.driver.execute_script(script, script_args=args or [])

    def content(self, script, args=None, suffix='/web/index.html'):
        return self.driver.execute_async_script('''
          const [script, args, suffix, addonId] = arguments;
          const done = arguments[arguments.length - 1];
          const window = Services.wm.getMostRecentWindow('mail:3pane');
          const policy = WebExtensionPolicy.getByID(addonId);
          const target = policy?.getURL(suffix.slice(1));
          const tab = window.document.getElementById('tabmail').tabInfo.find(
            tab => tab.browser?.currentURI.spec === target);
          if (!tab?.browser?.browsingContext?.currentWindowGlobal) {
            done({__driverError: 'The add-on tab is not ready.'}); return;
          }
          tab.browser.browsingContext.currentWindowGlobal
             .getActor('MarionetteCommands')
             .executeScript(script, args, {newSandbox: true, timeout: 25000})
             .then(done, error => done({__driverError: String(error)}));
        ''', script_args=[script, args or [], suffix, ADDON_ID])

    def checked_content(self, script, args=None, suffix='/web/index.html'):
        value = self.content(script, args, suffix)
        if isinstance(value, dict) and '__driverError' in value:
            raise RuntimeError(value['__driverError'])
        return value

    def wait(self, predicate, message, timeout=20):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                value = predicate()
                if value:
                    return value
            except Exception:
                pass
            time.sleep(.2)
        raise RuntimeError(message)

    def guard(self):
        profile = Path(self.chrome('return Services.dirsvc.get("ProfD", Ci.nsIFile).path;')).resolve()
        allowed = [Path('/tmp/inbox-thunderbird-runtime').resolve(), (ROOT / '.local/thunderbird-runtime').resolve()]
        if not any(profile.is_relative_to(root) and profile != root for root in allowed):
            raise RuntimeError('Refusing to run against a profile outside the task-owned temporary runtime.')
        marker = profile / '.inbox-companion-development-profile'
        if not marker.is_file() or marker.read_text() != 'Isolated Inbox Companion native development profile.\n':
            raise RuntimeError('Refusing to run against an unmarked profile. Start a fresh profile with the native runtime helper.')
        counts = self.chrome('''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          return {accounts:[...MailServices.accounts.accounts].length, identities:[...MailServices.accounts.allIdentities].length,
                  servers:[...MailServices.accounts.allServers].length};
        ''')
        if counts['accounts'] == 0:
            mail_data = [profile / 'Mail', profile / 'ImapMail']
            if counts['identities'] or counts['servers'] or any(path.exists() and (not path.is_dir() or any(path.iterdir())) for path in mail_data):
                raise RuntimeError('An account-free profile contains previous mail configuration or data; choose a new development profile.')
            self.chrome('''
              const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
              // Only the marked, empty development profile reaches this path.
              MailServices.accounts.createLocalMailAccount();
              const server = MailServices.accounts.localFoldersServer;
              const account = [...MailServices.accounts.accounts].find(account => account.incomingServer.key === server.key);
              if (!account) throw new Error('The synthetic Local Folders account was not created.');
              const identity = MailServices.accounts.createIdentity();
              identity.email = 'alex@example.com'; identity.fullName = 'Alex';
              account.addIdentity(identity); account.defaultIdentity = identity;
            ''')
        guard = self.chrome(r'''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          const accounts = [...MailServices.accounts.accounts];
          const safe = accounts.length === 1 && accounts.every(account =>
            account.incomingServer.type === 'none' &&
            [...account.identities].length > 0 &&
            [...account.identities].every(identity => identity.email === 'alex@example.com')) &&
            [...MailServices.accounts.allServers].every(server => server.type === 'none');
          let safeMessages = true;
          function visit(folder) {
            if (!folder.isServer) for (const header of folder.messages) {
              const addresses = (header.author + ' ' + header.recipients + ' ' + header.ccList)
                .match(/[^\s<>,;"()]+@[^\s<>,;"()]+/g) || [];
              if (!addresses.length || addresses.some(address => !/^[^@]+@example\.(?:com|net|org)$/i.test(address))) safeMessages = false;
            }
            for (const child of folder.subFolders) visit(child);
          }
          if (safe) visit(accounts[0].incomingServer.rootFolder);
          return {safe, safeMessages, accounts: accounts.length};
        ''')
        if not guard['safe'] or not guard['safeMessages']:
            raise RuntimeError('Refusing to mutate a profile containing anything beyond the reserved-address Local Folders fixture.')
        return profile

    def seed(self):
        date = format_datetime(datetime.now(timezone.utc))
        raw = (f'From: Sarah Chen <sarah@example.com>\r\nTo: Alex <alex@example.com>\r\n'
               f'Subject: {SUBJECT}\r\nDate: {date}\r\nMessage-ID: <{FIXTURE_ID}>\r\n'
               'MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n'
               'Hi Alex,\r\n\r\nCould you review the project scope before Thursday?\r\n\r\nThanks,\r\nSarah\r\n')
        return self.chrome('''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          const account = [...MailServices.accounts.accounts][0];
          const root = account.incomingServer.rootFolder;
          function child(name) {
            let folder;
            try { folder = root.getChildNamed(name); } catch {}
            if (!folder) { root.createSubfolder(name, null); folder = root.getChildNamed(name); }
            if (!folder) throw new Error('Could not create synthetic folder ' + name);
            return folder;
          }
          const inbox = child('Inbox'); inbox.setFlag(Ci.nsMsgFolderFlags.Inbox);
          const drafts = child('Drafts'); drafts.setFlag(Ci.nsMsgFolderFlags.Drafts);
          const archive = child('Archives'); archive.setFlag(Ci.nsMsgFolderFlags.Archive);
          const identity = [...account.identities][0];
          identity.draftsFolderURI = drafts.URI; identity.archivesFolderURI = archive.URI;
          identity.archiveEnabled = true; identity.archiveGranularity = 0;
          let header = [...inbox.messages].find(header => header.messageId === arguments[1]);
          if (!header) header = inbox.QueryInterface(Ci.nsIMsgLocalMailFolder).addMessage(arguments[0]);
          header.setStringProperty('keywords', '$label1');
          function count(name) { try { return root.getChildNamed(name).getTotalMessages(false); } catch { return 0; } }
          return {folder: inbox.URI, key: header.messageKey, draftsBefore: drafts.getTotalMessages(false), sentBefore:count('Sent'), outboxBefore:count('Outbox')};
        ''', [raw, FIXTURE_ID])

    def open_workspace(self, xpi):
        installed = Addons(self.driver).install(str(xpi), temp=True)
        if installed != ADDON_ID:
            raise RuntimeError('The package installed an unexpected add-on ID.')
        self.wait(lambda: self.chrome('return WebExtensionPolicy.getByID(arguments[0])?.extension.backgroundState === "running";', [ADDON_ID]), 'The native add-on background did not start.')
        self.chrome('''
          const window = Services.wm.getMostRecentWindow('mail:3pane');
          const button = window.document.querySelector('button[extension="inbox-companion@j-wpd.email"]');
          if (!button) throw new Error('The companion toolbar action is missing.');
          button.click();
        ''')
        self.wait(lambda: self.content('return Boolean(document.querySelector(".message-row"));') is True, 'The native inbox workspace did not render.')

    def select_fixture(self):
        self.checked_content('''
          const refresh = document.getElementById('refresh-button');
          if (refresh) refresh.click();
          return true;
        ''')
        self.wait(lambda: self.checked_content('''
          const row = [...document.querySelectorAll('.message-row')].find(row => row.textContent.includes(arguments[0]));
          if (!row) return false;
          row.click(); return true;
        ''', [SUBJECT]), 'The synthetic fixture is missing from the workspace.')
        self.wait(lambda: self.checked_content('return document.body.textContent.includes("Could you review the project scope before Thursday?");'), 'The selected native email body did not render.')

    def run(self, xpi, screenshot=None):
        self.guard()
        seeded = self.seed()
        self.open_workspace(xpi)
        self.select_fixture()
        self.checked_content('''
          const button = [...document.querySelectorAll('button')].find(button => button.textContent.trim() === 'Review with rules');
          if (!button) throw new Error('The rule-review action is missing.');
          button.click(); return true;
        ''')
        self.wait(lambda: self.checked_content('return document.body.textContent.includes("Suggested by simple keyword rules.");'), 'The native rule review did not finish.')
        self.checked_content('''
          const select = document.querySelector('select[aria-label="Category to apply"]');
          select.value = 'finance'; select.dispatchEvent(new Event('change', {bubbles:true}));
          const button = [...document.querySelectorAll('button')].find(button => button.textContent.trim() === 'Apply category');
          button.click(); return true;
        ''')
        self.wait(lambda: self.checked_content('return document.body.textContent.includes("Category applied: Finance.");'), 'The native category action did not finish.')
        category = self.checked_content('''return (async () => {
          const {createAdapter} = await import(new URL('./adapter.js', location.href));
          const adapter = await createAdapter();
          const message = (await adapter.listMessages()).find(message => message.subject === arguments[0]);
          return {id: message.id, category: message.category, bodyReadable: (await adapter.getMessage(message.id)).body.includes('project scope')};
        })();''', [SUBJECT])
        assert category['category'] == 'finance' and category['bodyReadable']
        tags = self.chrome('''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          const inbox = [...MailServices.accounts.accounts][0].incomingServer.rootFolder.getChildNamed('Inbox');
          return [...inbox.messages].find(header => header.messageId === arguments[0]).getStringProperty('keywords');
        ''', [FIXTURE_ID])
        assert '$label1' in tags
        if screenshot:
            screenshot.parent.mkdir(parents=True, exist_ok=True)
            self.driver.switch_to_window(self.driver.chrome_window_handles[0])
            screenshot.write_bytes(self.driver.screenshot(format='binary'))
        draft = self.checked_content('''return (async () => {
          const {createAdapter} = await import(new URL('./adapter.js', location.href));
          const adapter = await createAdapter();
          return adapter.openReply(arguments[0], 'Thank you, Sarah. I will review the project scope before Thursday.');
        })();''', [category['id']])
        assert draft['saved']
        counts = self.chrome('''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          const root = [...MailServices.accounts.accounts][0].incomingServer.rootFolder;
          const drafts = [...root.getChildNamed('Drafts').messages];
          // Thunderbird's message database stores Re: as a HasRe flag.
          const saved = drafts.find(header => header.subject === arguments[0] && (header.flags & Ci.nsMsgMessageFlags.HasRe));
          function count(name) { try { return root.getChildNamed(name).getTotalMessages(false); } catch { return 0; } }
          return {drafts: drafts.length, senderCorrect: saved?.author.includes('alex@example.com'), recipientCorrect: saved?.recipients.includes('sarah@example.com'), sent:count('Sent'), outbox:count('Outbox')};
        ''', [SUBJECT])
        assert counts['drafts'] > seeded['draftsBefore'] and counts['senderCorrect'] and counts['recipientCorrect']
        assert counts['sent'] == seeded['sentBefore'] and counts['outbox'] == seeded['outboxBefore']
        self.checked_content('''return (async () => {
          const {createAdapter} = await import(new URL('./adapter.js', location.href));
          const adapter = await createAdapter(); await adapter.archive(arguments[0]); return true;
        })();''', [category['id']])
        archived = self.chrome('''
          const {MailServices} = ChromeUtils.importESModule('resource:///modules/MailServices.sys.mjs');
          const root = [...MailServices.accounts.accounts][0].incomingServer.rootFolder;
          return {inInbox: [...root.getChildNamed('Inbox').messages].some(header => header.messageId === arguments[0]),
                  archived: [...root.getChildNamed('Archives').messages].some(header => header.messageId === arguments[0])};
        ''', [FIXTURE_ID])
        assert not archived['inInbox'] and archived['archived']
        pairing = {'checked': False}
        token_file = ROOT / '.local/session-token'
        if token_file.is_file():
            # The token is passed only to the native options input and never returned or printed.
            token = token_file.read_text().strip()
            self.checked_content('''return (async () => {
              const {createAdapter} = await import(new URL('./adapter.js', location.href));
              await (await createAdapter()).openSettings(); return true;
            })();''')
            self.wait(lambda: self.content('return Boolean(document.getElementById("connection-token"));', suffix='/options.html') is True, 'The native connection options did not open.')
            self.checked_content('''
              document.getElementById('connection-token').value = arguments[0];
              document.getElementById('settings-form').requestSubmit(); return true;
            ''', [token], suffix='/options.html')
            token = None
            self.wait(lambda: self.checked_content('return document.getElementById("status").textContent === "Connection settings saved.";', suffix='/options.html'), 'The native connection token could not be saved.')
            pairing = self.checked_content('''return (async () => {
              const {createAdapter} = await import(new URL('./web/adapter.js', location.href));
              const adapter = await createAdapter(); const settings = await adapter.getSettings(); const health = await adapter.health();
              return {checked:true, paired:settings.paired, serviceReachable:health.provider !== 'companion', aiReady:health.aiReady};
            })();''', suffix='/options.html')
            assert pairing['paired'] and pairing['serviceReachable']
        return {'nativeWorkspace': True, 'fixtureRead': True, 'rules': True, 'categoryPersisted': True,
                'existingTagsPreserved': True, 'replyDraftSaved': True, 'draftSenderMatched': True,
                'archiveMovedFixture': True, 'sentAndOutboxUnchanged': True, 'pairing': pairing,
                'aiGenerationTested': False, 'screenshot': str(screenshot) if screenshot else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=2828)
    parser.add_argument('--xpi', type=Path, default=ROOT / '.local/inbox-companion.xpi')
    parser.add_argument('--screenshot', type=Path)
    options = parser.parse_args()
    if not options.xpi.is_file():
        parser.error('Build the add-on package first.')
    smoke = NativeSmoke(options.port)
    try:
        print(json.dumps(smoke.run(options.xpi.resolve(), options.screenshot), indent=2))
    finally:
        smoke.driver.delete_session()


if __name__ == '__main__':
    main()
