#!/usr/bin/env bash
# Debian 13 development runtime. Extracts authenticated packages locally; never
# installs OS packages or changes the checkout's dependency/lock files.
set -euo pipefail
umask 077

script_directory="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repository_directory="$(cd -- "$script_directory/.." && pwd -P)"
runtime_directory="$repository_directory/.local/thunderbird-runtime"
runtime_root="$runtime_directory/root"

runtime_os_id="$(. /etc/os-release; printf '%s' "$ID")"
runtime_os_version="$(. /etc/os-release; printf '%s' "$VERSION_ID")"
if [[ "$runtime_os_id" != debian || "$runtime_os_version" != 13 || "$(uname -m)" != x86_64 ]]; then
  printf '%s\n' 'This native development runtime requires Debian 13 on amd64.' >&2
  exit 1
fi

check_runtime() {
  local root="$1" library_path
  library_path="$root/usr/lib/x86_64-linux-gnu:$root/usr/lib/thunderbird"
  [[ -x "$root/usr/lib/thunderbird/thunderbird-bin" && -x "$root/usr/bin/Xvfb" ]] || return 1
  LD_LIBRARY_PATH="$library_path" "$root/usr/lib/thunderbird/thunderbird-bin" --version >/dev/null 2>&1 || return 1
  LD_LIBRARY_PATH="$library_path" "$root/usr/bin/Xvfb" -help >/dev/null 2>&1 || return 1
  # --version alone does not load Gecko, so check its shared-library closure too.
  local dependencies
  dependencies="$(LD_LIBRARY_PATH="$library_path" ldd "$root/usr/lib/thunderbird/libxul.so")" || return 1
  [[ "$dependencies" != *'not found'* ]] || return 1
}

if check_runtime "$runtime_root"; then
  LD_LIBRARY_PATH="$runtime_root/usr/lib/x86_64-linux-gnu:$runtime_root/usr/lib/thunderbird" \
    "$runtime_root/usr/lib/thunderbird/thunderbird-bin" --version
  printf 'Reusing verified native runtime: %s\n' "$runtime_directory"
  exit 0
fi

for command in python3 /usr/bin/apt-get /usr/bin/apt-cache /usr/bin/dpkg-deb ldd; do
  command -v "$command" >/dev/null || { printf 'Required runtime setup tool is missing: %s\n' "$command" >&2; exit 1; }
done

mkdir -p -- "$runtime_directory"
python3 - "$runtime_directory" <<'PY'
import json
import sys
from pathlib import Path

base = Path(sys.argv[1])
keyring = Path('/usr/share/keyrings/debian-archive-keyring.pgp')
if not keyring.is_file():
    keyring = Path('/usr/share/keyrings/debian-archive-keyring.gpg')
if not keyring.is_file():
    raise SystemExit('The Debian archive verification keyring is missing.')
for relative in ['apt/state/lists/partial', 'apt/cache/archives/partial', 'apt/config/parts', 'apt/log']:
    (base / relative).mkdir(parents=True, exist_ok=True, mode=0o700)
sources = base / 'apt/config/sources.list'
sources.write_text(
    f'deb [signed-by={keyring}] https://deb.debian.org/debian trixie main\n'
    f'deb [signed-by={keyring}] https://deb.debian.org/debian-security trixie-security main\n'
)
locations = {
    'Dir::Etc::main': base / 'apt/config/apt.conf',
    'Dir::Etc::parts': base / 'apt/config/parts',
    'Dir::Etc::sourcelist': sources,
    'Dir::Etc::sourceparts': base / 'apt/config/parts',
    'Dir::State': base / 'apt/state',
    'Dir::State::status': Path('/var/lib/dpkg/status'),
    'Dir::Cache': base / 'apt/cache',
    'Dir::Log': base / 'apt/log',
}
(base / 'apt/config/apt.conf').write_text(
    ''.join(f'{name} {json.dumps(str(value))};\n' for name, value in locations.items())
    + 'Acquire::Languages "none";\n'
)
PY

apt_configuration="$runtime_directory/apt/config/apt.conf"
# Dedicated configuration prevents apt from changing system sources, cache, or
# state. Default signature, validity, HTTPS, and package-hash verification remain.
APT_CONFIG="$apt_configuration" /usr/bin/apt-get update
staging_directory="$(mktemp -d "$runtime_directory/staging.XXXXXXXX")"
cleanup_staging() { rm -rf -- "$staging_directory"; }
trap cleanup_staging EXIT
mkdir -- "$staging_directory/downloads" "$staging_directory/root"
runtime_packages=(thunderbird xvfb libbotan-2-19 libotr5t64 librnp0 libsexpp0 libtspi1)
(
  cd -- "$staging_directory/downloads"
  APT_CONFIG="$apt_configuration" /usr/bin/apt-get download "${runtime_packages[@]}"
)

# Independently verify each downloaded artifact against the SHA256 authenticated
# by apt's signed Packages index, before extracting any artifact.
APT_CONFIG="$apt_configuration" python3 - "$staging_directory" "${runtime_packages[@]}" <<'PY'
import hashlib
import re
import subprocess
import sys
from pathlib import Path

staging = Path(sys.argv[1])
packages = sys.argv[2:]
metadata = subprocess.check_output(
    ['/usr/bin/apt-cache', '--no-all-versions', 'show', *packages], text=True
)
expected = {}
for record in metadata.strip().split('\n\n'):
    fields = {}
    for line in record.splitlines():
        if line and not line[0].isspace() and ':' in line:
            key, value = line.split(':', 1)
            fields[key] = value.strip()
    if all(key in fields for key in ['Package', 'Version', 'Architecture', 'SHA256']):
        expected[(fields['Package'], fields['Version'], fields['Architecture'])] = fields['SHA256']
archives = sorted((staging / 'downloads').glob('*.deb'))
if len(archives) != len(packages):
    raise SystemExit('The package download set is incomplete; nothing will be extracted.')
checked = []
for archive in archives:
    details = tuple(subprocess.check_output(
        ['/usr/bin/dpkg-deb', '--field', str(archive), key], text=True
    ).strip() for key in ['Package', 'Version', 'Architecture'])
    wanted = expected.get(details, '')
    actual = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
    if not re.fullmatch(r'[0-9a-f]{64}', wanted) or actual != wanted:
        raise SystemExit(f'Package verification failed for {archive.name}; no extraction performed.')
    checked.append(archive)
for archive in checked:
    subprocess.run(['/usr/bin/dpkg-deb', '--extract', str(archive), str(staging / 'root')], check=True)
print(f'Verified SHA256 and extracted {len(checked)} authenticated Debian packages.')
PY

if ! check_runtime "$staging_directory/root"; then
  printf '%s\n' 'The extracted runtime is missing host framework libraries. This helper expects the standard Debian 13 cloud GTK/X11/NSS libraries; it does not install system packages.' >&2
  exit 1
fi
if [[ -e "$runtime_root" ]]; then
  # Preserve any existing runtime rather than overwriting files blindly.
  mv -- "$runtime_root" "$runtime_directory/root.previous-${staging_directory##*.}"
fi
mv -- "$staging_directory/root" "$runtime_root"
LD_LIBRARY_PATH="$runtime_root/usr/lib/x86_64-linux-gnu:$runtime_root/usr/lib/thunderbird" \
  "$runtime_root/usr/lib/thunderbird/thunderbird-bin" --version
printf 'Verified native runtime prepared: %s\n' "$runtime_directory"
